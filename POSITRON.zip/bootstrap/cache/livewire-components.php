<?php return array (
  'form-crear-empresa-dosimetria' => 'App\\Http\\Livewire\\FormCrearEmpresaDosimetria',
  'form-departamento' => 'App\\Http\\Livewire\\FormDepartamento',
  'form-lectura-dosimetro-contrato' => 'App\\Http\\Livewire\\FormLecturaDosimetroContrato',
  'form-personas-perfiles' => 'App\\Http\\Livewire\\FormPersonasPerfiles',
  'form-personas-roles' => 'App\\Http\\Livewire\\FormPersonasRoles',
  'form-trabajador' => 'App\\Http\\Livewire\\FormTrabajador',
  'insert-newtableasig' => 'App\\Http\\Livewire\\InsertNewtableasig',
  'search-asignaciones' => 'App\\Http\\Livewire\\SearchAsignaciones',
  'search-asignaciones-entrada' => 'App\\Http\\Livewire\\SearchAsignacionesEntrada',
  'search-empresa-dosi-component' => 'App\\Http\\Livewire\\SearchEmpresaDosiComponent',
  'search-personas-component' => 'App\\Http\\Livewire\\SearchPersonasComponent',
);