@extends('layouts.app')
@extends('layouts.plantillabase')
@section('contenido')

@livewire('search-asignaciones-entrada') 
  
@endsection