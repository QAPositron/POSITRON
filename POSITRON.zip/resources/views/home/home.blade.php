@section('contenido')
 <h3 class="text-center"> BIENVENIDO A QAPOSITRON</h3>
@endsection()