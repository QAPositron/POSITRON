

<?php $__env->startSection('contenido'); ?>
<div class="row"> 
    <div class="col"></div>
    <div class="col-10">
        <div class="card text-dark bg-light">
            <h2 class="text-center mt-3">EDITAR EMPRESA</h2>
             
            <form class="m-4"  id="form_edit_empresa" name="form_edit_empresa" action="<?php echo e(route('empresas.update', $empresa)); ?>" method="POST">
                
                <?php echo csrf_field(); ?>

                <?php echo method_field('put'); ?>

                <div class="row g-2">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="text" class="form-control <?php $__errorArgs = ['nombre_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre_empresa" id="nombre_empresa" value="<?php echo e(old('nombre_empresa', $empresa->nombre_empresa)); ?>" autofocus style="text-transform:uppercase">
                            <label for="floatingInput">NOMBRE</label>
                            <?php $__errorArgs = ['nombre_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating" >
                            <select class="form-select <?php $__errorArgs = ['tipo_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipo_empresa" id="tipo_empresa" value="<?php echo e(old('tipo_empresa', $empresa->tipo_empresa)); ?>" autofocus style="text-transform:uppercase  ">
                                <option value="<?php echo e($empresa->tipo_empresa); ?>"><?php echo e($empresa->tipo_empresa); ?></option>
                                <option value="persona natural" <?php if(old('tipo_empresa') == "persona natural"): ?> <?php echo e('selected'); ?> <?php endif; ?>>PERSONA NATURAL</option>
                                <option value="persona juridica" <?php if(old('tipo_empresa') == "persona juridica"): ?> <?php echo e('selected'); ?> <?php endif; ?>>PERSONA JURIDICA</option>
                            </select>
                            <label for="floatingInputGrid">TIPO:</label>
                            <?php $__errorArgs = ['tipo_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating">
                            <select class="form-select <?php $__errorArgs = ['tipoIden_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipoIden_empresa" id="tipoIden_empresa" autofocus  style="text-transform:uppercase;">
                                <option value="<?php echo e($empresa->tipo_identificacion_empresa); ?>"><?php echo e(old('tipoIden_empresa', $empresa->tipo_identificacion_empresa)); ?></option>
                                <option value="nit"  <?php if(old('tipoIden_empresa') == "nit"): ?> <?php echo e('selected'); ?> <?php endif; ?>>NIT</option>
                                <option value="CÉDULA DE EXTRANJERÍA"  <?php if(old('tipoIden_empresa') == "CÉDULA DE EXTRANJERÍA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>CÉDULA DE EXTRANJERÍA</option>
                                <option value="TARJETA DE EXTRANJERÍA"  <?php if(old('tipoIden_empresa') == "TARJETA DE EXTRANJERÍA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>TARJETA DE EXTRANJERÍA</option>
                                <option value="DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO"  <?php if(old('tipoIden_empresa') == "DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO"): ?> <?php echo e('selected'); ?> <?php endif; ?>>DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO</option>
                                <option value="TARJETA DE IDENTIDAD"  <?php if(old('tipoIden_empresa') == "TARJETA DE IDENTIDAD"): ?> <?php echo e('selected'); ?> <?php endif; ?>>TARJETA DE IDENTIDAD</option>
                                <option value="CÉDULA DE CIUDADANIA"  <?php if(old('tipoIden_empresa') == "CÉDULA DE CIUDADANIA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>CÉDULA DE CIUDADANIA</option>
                                <option value="REGISTRO CIVIL"  <?php if(old('tipoIden_empresa') == "REGISTRO CIVIL"): ?> <?php echo e('selected'); ?> <?php endif; ?>>REGISTRO CIVIL</option>
                                <option value="PASAPORTE"  <?php if(old('tipoIden_empresa') == "PASAPORTE"): ?> <?php echo e('selected'); ?> <?php endif; ?>>PASAPORTE</option>
                            </select>
                            <label for="floatingInputGrid">TIPO DE IDENTIFICACIÓN:</label>
                            <?php $__errorArgs = ['tipoIden_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!------------------ CAMPO QUE CAMBIA DINAMICAMENTE----->
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="numeric" name="numero_ident" id="numero_ident" class="form-control <?php $__errorArgs = ['numero_ident'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('numero_ident', $empresa->num_iden_empresa)); ?>"  autofocus> 
                            <label for="floatingInputGrid" id="numero_identificacion"><?php echo e($empresa->tipo_identificacion_empresa); ?></label>
                            <?php $__errorArgs = ['numero_ident'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="form-floating" >
                            <input type="numeric" name="nitdv_empresa" id="nitdv_empresa" class="form-control <?php $__errorArgs = ['nitdv_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nitdv_empresa', $empresa->DV)); ?>" autofocus style="visibility: hidden"> 
                            <label for="floatingInputGrid" name="label_nit_dv_empresa" id="label_nit_dv_empresa" style="visibility: hidden">DV:</label>
                            <?php $__errorArgs = ['nitdv_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!------------------------------------------>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating" >
                            <input type="numeric" name="actividad_empresa" id="actividad_empresa" class="form-control <?php $__errorArgs = ['actividad_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('actividad_empresa', $empresa->actividad_economica_empresa)); ?>"  autofocus >
                            <label for="floatingInputGrid">ACTIVIDAD ECONÓMICA PRINCIPAL:</label>
                            <?php $__errorArgs = ['actividad_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <select class="form-select <?php $__errorArgs = ['respoIva_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="respoIva_empresa" id="respoIva_empresa" autofocus style="text-transform:uppercase;">
                                <option value="<?php echo e($empresa->respo_iva_empresa); ?>"><?php echo e(old('respoIva_empresa', $empresa->respo_iva_empresa)); ?></option>
                                <option value="NO RESPONSABLE DE IVA" <?php if(old('respoIva_empresa') == "NO RESPONSABLE DE IVA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>NO RESPONSABLE DE IVA</option>
                                <option value="RESPONSABLE DE IVA" <?php if(old('respoIva_empresa') == "RESPONSABLE DE IVA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>RESONSABLE DE IVA</option>
                            </select>
                            <label for="floatingInputGrid">RESPONSABILIDAD IVA:</label>
                            <?php $__errorArgs = ['respoIva_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating" >
                            <select class="form-select <?php $__errorArgs = ['respoFiscal_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="respoFiscal_empresa" id="respoFiscal_empresa"  autofocus style="text-transform:uppercase;">
                                <option value="<?php echo e($empresa->respo_fiscal_empresa); ?>"><?php echo e(old('respoFiscal_empresa', $empresa->respo_fiscal_empresa)); ?></option>
                                <option value="NO RESPONSABLE (R-99-PN)" <?php if(old('respoFiscal_empresa') == "NO RESPONSABLE (R-99-PN)"): ?> <?php echo e('selected'); ?> <?php endif; ?>>NO RESPONSABLE (R-99-PN)</option>
                                <option value="REGIMEN SIMPLE DE TRIBUTACIÓN (O-47)" <?php if(old('respoFiscal_empresa') == "REGIMEN SIMPLE DE TRIBUTACIÓN (O-47)"): ?> <?php echo e('selected'); ?> <?php endif; ?>>REGIMEN SIMPLE DE TRIBUTACIÓN (O-47)</option>
                                <option value="GRAN CONTRIBUYENTE (O-13)"  <?php if(old('respoFiscal_empresa') == "GRAN CONTRIBUYENTE (O-13)"): ?> <?php echo e('selected'); ?> <?php endif; ?>>GRAN CONTRIBUYENTE (O-13)</option>
                                <option value="AUTORRETENEDOR (O-15)" <?php if(old('respoFiscal_empresa') == "AUTORRETENEDOR (O-15)"): ?> <?php echo e('selected'); ?> <?php endif; ?>>AUTORRETENEDOR (O-15)</option>
                                <option value="AGENTE DE RETENCIÓN IVA(O-23)"  <?php if(old('respoFiscal_empresa') == "AGENTE DE RETENCIÓN IVA(O-23)"): ?> <?php echo e('selected'); ?> <?php endif; ?>>AGENTE DE RETENCIÓN IVA(O-23)</option>
                            </select>
                            <label for="floatingInputGrid">RESPONSABILIDAD FISCAL:</label>
                            <?php $__errorArgs = ['respoFiscal_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="numeric" name="telefono_empresa" id="telefono_empresa" class="form-control  <?php $__errorArgs = ['telefono_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('telefono_empresa', $empresa->telefono_empresa)); ?>" autofocus >
                            <label for="floatingInputGrid">TELÉFONO:</label>
                            <?php $__errorArgs = ['telefono_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div> 
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="email" name="correo_empresa" id="correo_empresa" class="form-control <?php $__errorArgs = ['correo_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('correo_empresa', $empresa->email_empresa)); ?>" autofocus style="text-transform:uppercase;"> 
                            <label for="floatingInputGrid">CORREO ELECTRONICO:</label>
                            <?php $__errorArgs = ['correo_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" name="direccion_empresa" id="direccion_empresa" class="form-control <?php $__errorArgs = ['direccion_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('direccion_empresa', $empresa->direccion_empresa)); ?>" autofocus style="text-transform:uppercase;"> 
                            <label for="floatingInputGrid">DIRECCIÓN:</label>
                            <?php $__errorArgs = ['direccion_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="numeric" name="pais_empresa" id="pais_empresa" class="form-control" value="<?php echo e(old('pais_empresa', $empresa->pais_empresa)); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">PAÍS:</label>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-group">
                            <label for="floatingInputGrid">DEPARTAMENTO:</label>
                            <select class="form-control <?php $__errorArgs = ['departamento_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="departamento_empresa" id="departamento_empresa" value="<?php echo e(old('departamento_empresa')); ?>" autofocus style="text-transform:uppercase">
                                <option value="<?php echo e($empresa->municipios->coldepartamento->id_departamentocol); ?>">--<?php echo e($empresa->municipios->coldepartamento->nombre_deptocol); ?>--</option>
                                <?php $__currentLoopData = $departamentoscol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depacol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($depacol->id_departamentocol); ?>" <?php if(old('departamento_empresa') == $depacol->id_departamentocol): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($depacol->nombre_deptocol); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['departamento_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md" id="div_municipio">
                        <div class="spinner_municipio text-center" id="spinner_municipio">

                        </div>

                        <div class="form-group" id="municipio_empresa" name="municipio_empresa">
                            <label for="floatingInputGrid">MUNICIPIO:</label>
                            <select class="form-control <?php $__errorArgs = ['ciudad_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ciudad_empresa" id="ciudad_empresa" value="<?php echo e(old('ciudad_empresa')); ?>" autofocus style="text-transform:uppercase">
                                <option value="<?php echo e($empresa->municipios->id_municipiocol); ?>">--<?php echo e($empresa->municipios->nombre_municol); ?>--</option>
                            </select>
                            <?php $__errorArgs = ['ciudad_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col md">
                        <div class="form-floating">
                            <input type="text" name="nombreRepr_empresa" id="nombreRepr_empresa" class="form-control <?php $__errorArgs = ['nombreRepr_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nombreRepr_empresa', $empresa->nombre_representantelegal)); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">* NOMBRE(s) Y APELLIDO(s) REPR. LEGAL</label>
                            <?php $__errorArgs = ['nombreRepr_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <select class="form-select <?php $__errorArgs = ['tipoIden_repreLegal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipoIden_repreLegal" id="tipoIden_repreLegal" value="<?php echo e(old('tipoIden_repreLegal')); ?>" autofocus style="text-transform:uppercase">
                                <option value="<?php echo e($empresa->tipo_iden_representantelegal); ?>">--<?php echo e(old('tipoIden_repreLegal', $empresa->tipo_iden_representantelegal)); ?>--</option>
                                <option value="CÉDULA DE CIUDADANIA" <?php if(old('tipoIden_repreLegal') == "CÉDULA DE CIUDADANIA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>CÉDULA DE CIUDADANIA</option>
                                <option value="TARJETA DE IDENTIDAD" <?php if(old('tipoIden_repreLegal') == "TARJETA DE IDENTIDAD"): ?> <?php echo e('selected'); ?> <?php endif; ?>>TARJETA DE IDENTIDAD</option>
                                <option value="REGISTRO CIVIL" <?php if(old('tipoIden_repreLegal') == "REGISTRO CIVIL"): ?> <?php echo e('selected'); ?> <?php endif; ?>>REGISTRO CIVIL</option>
                                <option value="TARJETA DE EXTRANJERÍA" <?php if(old('tipoIden_repreLegal') == "TARJETA DE EXTRANJERÍA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>TARJETA DE EXTRANJERÍA</option>
                                <option value="DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO" <?php if(old('tipoIden_repreLegal') == "DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO"): ?> <?php echo e('selected'); ?> <?php endif; ?>>DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO</option>
                                <option value="CÉDULA DE EXTRANJERÍA" <?php if(old('tipoIden_repreLegal') == "CÉDULA DE EXTRANJERÍA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>CÉDULA DE EXTRANJERÍA</option>
                                <option value="PASAPORTE"  <?php if(old('tipoIden_repreLegal') == "PASAPORTE"): ?> <?php echo e('selected'); ?> <?php endif; ?>>PASAPORTE</option>
                            </select>
                            <label for="floatingInputGrid">* TIPO DE IDENTIFICACIÓN REPR. LEGAL:</label>
                            <?php $__errorArgs = ['tipoIden_repreLegal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="number" name="cedula_Repr_empresa" id="cedula_Repr_empresa" class="form-control <?php $__errorArgs = ['cedula_Repr_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cedula_Repr_empresa', $empresa->cedula_representantelegal)); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">* N° DE IDENTIFICACIÓN REPR. LEGAL</label>
                            <?php $__errorArgs = ['cedula_Repr_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                 <!---------BOTON------------->
                <div class="row">
                    <div class="col"></div>
                    <div class="col d-grid gap-2">
                        <button class="btn colorQA " type="submit" id="boton-guardar" name="boton-guardar">ACTUALIZAR</button>
                    </div>
                    <div class="col d-grid gap-2">
                        <a href="<?php echo e(route('empresas.search')); ?>" class="btn btn-danger " type="button" id="cancelar" name="cancelar" role="button">CANCELAR</a>
                    </div>
                    <div class="col"></div>
                </div>
            </form>
        </div>
        <br>
    </div>
    <div class="col"></div>
</div>
<script type="text/javascript"> 
        
    var tipo = document.getElementById("tipoIden_empresa");
    var selected = tipo.options[tipo.selectedIndex].text;
    
    var inputText = document.getElementById("nitdv_empresa");
    var labelInput= document.getElementById("label_nit_dv_empresa"); 
    if(selected=="NIT"){
        inputText.style.visibility="visible";
        labelInput.style.visibility="visible";
    }else{
        inputText.style.visibility="hidden";
        
        labelInput.style.visibility="hidden";
    }
    
</script>
<script
src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous">
</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>   

<script type="text/javascript">
    $(document).ready(function() {
        $('#departamento_empresa').select2();
        $('#ciudad_empresa').select2();
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#departamento_empresa').on('change', function(){
            $('#municipio_empresa').fadeOut();
            $('#spinner_municipio').html('<div class="spinner-border text-secondary" id="spinner" role="status"></div>');
            var departamento_id = $(this).val();
            /* alert(departamento_id); */
            var padre = document.getElementById("spinner_municipio");
            var hijo = document.getElementById("spinner");
            if($.trim(departamento_id) != ''){
                $.get('empresasdeptomuni', {departamento_id: departamento_id}, function(municipios){
                    console.log(municipios);
                    var remove = padre.removeChild(hijo);
                    $('#municipio_empresa').fadeIn();
                    $('#ciudad_empresa').empty();
                    $('#ciudad_empresa').append("<option value='<?php echo e($empresa->municipios->id_municipiocol); ?>'>--<?php echo e($empresa->municipios->nombre_municol); ?>--</option>");
                    $.each(municipios, function(index, value){
                        $('#ciudad_empresa').append("<option value='"+ index + "'>" + value + "</option>");
                    })
                });
            }
        });
    });
</script>

<script type="text/javascript">
$(document).ready(function(){
    $('#form_edit_empresa').submit(function(e){
        e.preventDefault();
        Swal.fire({
            text: 'SEGURO QUE DESEA ACTUALIZAR LA INFORMACIÓN DE ESTA EMPRESA?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
                
                this.submit(); 
            }
        })
    })
})
</script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/empresa/edit_empresa.blade.php ENDPATH**/ ?>