<div>
    <form class="m-4 form_create_trabajador"  id="form_create_trabajador" name="form_create_trabajador" wire:submit.prevent="saveTrabajador">

        <?php echo csrf_field(); ?>

        <div class="row g-2">
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <input type="text" class="form-control" name="empresas_id" id="empresas_id" value="<?php echo e($nombre_empresa); ?>" autofocus style="text-transform:uppercase;" disabled>
                    <input wire:model="id_empresa" type="number" class="form-control <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"   name="id_empresas" id="id_empresas" hidden>
                    <label for="floatingSelectGrid">EMPRESA:</label>
                    <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating">
                    <select wire:model="sede" class="form-select <?php $__errorArgs = ['sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_sedes" id="id_sedes">
                        <option value="<?php echo e(old('id_sedes')); ?>">--SELECCIONE--</option>
                        <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value ="<?php echo e($sed->id_sede); ?>"><?php echo e($sed->nombre_sede); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="floatingSelectGrid">SEDE:</label>
                    <?php $__errorArgs = ['sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row g-2">
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <input type="text" wire:model="primer_nombre" class="form-control  <?php $__errorArgs = ['primer_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="primer_nombre_trabajador" id="primer_nombre_trabajador"  autofocus style="text-transform:uppercase;" value="<?php echo e(old('primer_nombre_trabajador')); ?>">
                    <label for="floatingInputGrid">PRIMER NOMBRE:</label>
                    <?php $__errorArgs = ['primer_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <input type="text" wire:model="segundo_nombre" class="form-control <?php $__errorArgs = ['segundo_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="segundo_nombre_trabajador" id="segundo_nombre_trabajador"  autofocus style="text-transform:uppercase;" value="<?php echo e(old('segundo_nombre_trabajador')); ?>">
                    <label for="floatingInputGrid">SEGUNDO NOMBRE:</label>
                    <?php $__errorArgs = ['segundo_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row g-2">
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <input type="text" wire:model="primer_apellido" class="form-control <?php $__errorArgs = ['primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="primer_apellido_trabajador" id="primer_apellido_trabajador" autofocus style="text-transform:uppercase;">
                    <label for="floatingInputGrid">PRIMER APELLIDO:</label>
                    <?php $__errorArgs = ['primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <input type="text" wire:model="segundo_apellido" class="form-control  <?php $__errorArgs = ['segundo_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="segundo_apellido_trabajador" id="segundo_apellido_trabajador" value="<?php echo e(old('segundo_apellido_trabajador')); ?>" autofocus style="text-transform:uppercase;">
                    <label for="floatingInputGrid">SEGUNDO APELLIDO:</label>
                    <?php $__errorArgs = ['segundo_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row g-2">
            <div class="col-md">
                <div class="form-floating">
                    <select wire:model="tipo_identificación" class="form-select <?php $__errorArgs = ['tipo_identificación'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipoIden_trabajador" id="tipoIden_trabajador" value="<?php echo e(old('tipoIden_trabajador')); ?>" autofocus style="text-transform:uppercase">
                        <option value="">--SELECCIONE--</option>
                        <option value="CÉDULA DE CIUDADANIA">CÉDULA DE CIUDADANIA</option>
                        <option value="TARJETA DE IDENTIDAD">TARJETA DE IDENTIDAD</option>
                        <option value="REGISTRO CIVIL">REGISTRO CIVIL</option>
                        <option value="PASAPORTE">PASAPORTE</option>
                        <option value="CÉDULA DE EXTRANJERÍA">CÉDULA DE EXTRANJERÍA</option>
                        <option value="TARJETA DE EXTRANJERÍA">TARJETA DE EXTRANJERÍA</option>
                        <option value="DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO">DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO</option>
                    </select>
                    <label for="floatingInputGrid">TIPO DE IDENTIFICACIÓN:</label>
                    <?php $__errorArgs = ['tipo_identificación'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating">
                    <input wire:model="cédula" type="number" class="form-control <?php $__errorArgs = ['cédula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="cedula_trabajador" id="cedula_trabajador" value="<?php echo e(old('cedula_trabajador')); ?>" autofocus >
                    <label for="floatingInputGrid">CÉDULA:</label>
                    <?php $__errorArgs = ['cédula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row g-2">
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <select wire:model="género" class="form-select <?php $__errorArgs = ['género'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="genero_trabajador" id="genero_trabajador" style="text-transform:uppercase;">
                        <option value="<?php echo e(old('genero_trabajador')); ?>">--SELECCIONE--</option>
                        <option value="F">FEMENINO</option>
                        <option value="M">MASCULINO</option>
                        <option value="O">OTRO</option>
                    </select>
                    <label for="floatingInputGrid">GÉNERO:</label>
                    <?php $__errorArgs = ['género'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <input wire:model="correo" type="email" class="form-control <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="correo_trabajador" id="correo_trabajador" value="<?php echo e(old('correo_trabajador')); ?>" autofocus style="text-transform:uppercase;">
                    <label for="">CORREO:</label>
                    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <br>
        <div class="row g-2">
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <input wire:model="teléfono" type="number" class="form-control <?php $__errorArgs = ['teléfono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="telefono_trabajador" id="telefono_trabajador" value="<?php echo e(old('telefono_trabajador')); ?>" autofocus style="text-transform:uppercase;">
                    <label for="floatingInputGrid">TELÉFONO:</label>
                    <?php $__errorArgs = ['teléfono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating text-wrap">
                    <select wire:model="perfil_laboral" class="form-select <?php $__errorArgs = ['perfil_laboral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipo_trabajador" id="tipo_trabajador" style="text-transform:uppercase;" autofocus aria-label="Floating label select example">
                        <option value="<?php echo e(old('tipo_trabajador')); ?>">--SELECCIONE--</option>
                        <option value="TOE">TOE: TRABAJADOR OCUPACIONALMENTE EXPUESTO</option>
                        <option value="OPR">OPR: OFICIAL DE PROTECCIÓN RADIOLÓGICA</option>
                        <option value="CASO">CASO: TRABAJADOR CON DOSIMETRO TIPO CASO</option>
                    </select>
                    <label for="">PERFIL LABORAL:</label>
                    <?php $__errorArgs = ['perfil_laboral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <br>
        
            
        <!---------BOTON------------->
        <div class="row">
            <div class="col"></div>
            <div class="col d-grid gap-2">
                <input class="btn colorQA" type="submit" id="boton-guardar" name="boton-guardar" value="GUARDAR">
            </div>
            <div class="col d-grid gap-2">
                <a href="<?php echo e(route('empresas.info', $id_empresa)); ?>" class="btn btn-danger " type="button" id="cancelar" name="cancelar" role="button">CANCELAR</a>
            </div>
            <div class="col"></div>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/livewire/form-trabajador.blade.php ENDPATH**/ ?>