<style type="text/css">
    
    html{
        margin: 30pt 30pt 30pt 30pt;
        font-family: sans-serif;
        font-size: 10px;
    }
    
    .page-break {
        page-break-after: always;
    }

    .verticalText {
        writing-mode: vertical-lr;
        transform: rotate(-90deg);
        
    }
    
    .anchoCell{
        width: 20px;
        writing-mode: vertical-lr;
        transform: rotate(-90deg);
        
    }
    table{
        border-collapse: collapse; 
        /* cellspacing: 10px;
        cellpadding: 10px; */
        border: 0.3px;
        position:absolute; 
        top:150px; 
        /*left:220px;*/
    }
    img{
        position:absolute; 
        top:10px; 
        
    }
    
    .parrafo-border{
        position:absolute; 
        top:500px;
        border: 1px;
    }
    
</style>
<body>
    
<!-- ////////////////////ENCABEZADO/////////////// -->


<img src="<?php echo e(asset('imagenes/VerdeSF.png')); ?>" width="200">
<!-- <img src="public_path('../public/imagenes/LOGOVERDE.png');" width="200"> -->

<h3 style="position:absolute; top:87px; left:30px;">REPORTE DE DOSIMETRÍA</h3>

<table style="position:absolute; top:0px; left:240px;" cellspacing="0" cellpadding="0">
    <tr>
        <th style="font-size: 15px;" align="left">QA POSITRON S.A.S.</th>
    </tr>
    <tr>
        <td>NIT: 901390101-3, Licencia Ministerio de Minas y Energía No. CCD-00X 11-Feb-00</td>
    </tr>
    <tr>
        <td>Calle 36 #27-71 MILLENIUM BUSSINES TOWER, Oficina 919, Bucaramanga - Santander, Colombia</td>
    </tr>
    <tr>
        <td>Cel: 301 4495401 - 304 3386581</td>
    </tr>
    <tr>
        <td>Email:dosimetria.qapositron@gmail.com</td>
    </tr>
    <tr>
        <td style="padding-bottom:12px;">Sitio web: www.qapositron.com</td>
    </tr>
    <tr>
        <th style="font-size: 11px; border: solid 0.4px #000; padding:5px;">
            <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($cont->nombre_empresa); ?> - SEDE: <?php echo e($cont->nombre_sede); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </th>
    </tr>
</table>

<table style="position:absolute; top:0px; left:713px; border-collapse:collapse; font-size: 9px;" cellpadding="4">
    <tr>
        <td style="border:0.1px solid black; text-align: right;">No. de Cuenta</td>
        <td style="width: 120px; border:0.1px solid black; color:#2646FA;" align="center">
        <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($cont->codigo_contrato); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td style="border:0.1px solid black; text-align: right;">Fecha recibo dosím.</td>
        <td style="width: 94px; border:0.1px solid black; color:#2646FA;" align="center">

            <?php
                $chek = null;
            ?>      
            <?php $__currentLoopData = $trabajdosiasig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php
                    if($trabj->fecha_dosim_recibido != $chek){
                        $datefix = date('d-m-Y',strtotime($trabj->fecha_dosim_recibido));
                        echo "{$datefix}";
                        $chek = strval($trabj->fecha_dosim_recibido);
                    }else{ 
                        echo " ";
                    }
                ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td rowspan="6" style="width: 130px; border:0.1px solid black;">
            <img src="<?php echo e(asset('imagenes/LOGODOSIMETRIA.png')); ?>" width="127" style="top:15px;"> 
        </td>
    </tr>
    <tr>
        <td style="border:0.1px solid black; text-align: right;">Código Depto.</td>
        <td style="width: 94px; border:0.1px solid black; color:#2646FA;" align="center">
            
            <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($cont->nombre_departamento); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td style="border:0.1px solid black; text-align: right;">Fecha del reporte</td>
        <td style="width: 94px; border:0.1px solid black; color:#2646FA;" align="center">
        <?php
            $fecha = date("d-m-Y");
            echo "$fecha";
        ?>
        </td>
    </tr>
    <tr>
        <td style="border:0.1px solid black; text-align: right;"> NIT Entidad Usuaria</td>
        <td style="width: 120px; border:0.1px solid black; color:#2646FA;" align="center">
            <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($cont->num_iden_empresa); ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </td>
        <td colspan="2" rowspan="1" style="width: 50px; border:0.1px solid black;" align="center">Vo.Bo. / <b>DIEGO F. APONTE CASTAÑEDA</b> </td>
    </tr>
    <tr>
        <td style="border:0.1px solid black; text-align: right;">Municipio / Depto</td>
        <td style="width: 120px; border:0.1px solid black; color:#2646FA;" align="center">
        <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($cont->nombre_municol); ?> - <?php echo e($cont->abreviatura_deptocol); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </td>
        <td colspan="2" rowspan="3" style="width: 94px; border:0.1px solid black;">
            <img src="<?php echo e(asset('imagenes/FIRMADEDIEGOFINAL.png')); ?>" width="170" height="48" style="top:65px; ">
        </td>
    </tr>
    <tr>
        <td style="border:0.1px solid black; text-align: right;">Persona Contacto</td>
        <td style="width: 120px; border:0.1px solid black; color:#2646FA;" align="center">
            <?php $__currentLoopData = $personaEncargada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($per->primer_nombre_persona); ?> <?php echo e($per->primer_apellido_persona); ?> <?php echo e($per->segundo_apellido_persona); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
       
    </tr>
    <tr>
        <td style="border:0.1px solid black; text-align: right;">Cargo del contacto</td>
        <td style="width: 120px; border:0.1px solid black; color:#2646FA;" align="center">
            <?php $__currentLoopData = $personaEncargada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($per->nombre_perfil); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
    </tr>
</table>    





<!-- ////////////////////FIN ENCABEZADO/////////////// -->

<!-- ////////////////////CUERPO/////////////// -->
<table style="top:140px; border-collapse:collapse;" cellspacing="4" cellpadding="0" class="tablaPrincipal">
    <thead style="background-color:#DADADA;">
        <tr align="center">
            <th rowspan="2" style="width:60px; border:1px solid black;">Código Dosímetro </th>
            <th rowspan="2" style="width:125px; padding:5px; border:1px solid black;">Apellido(s)</th>
            <th rowspan="2" style="width:125px; padding:5px; border:1px solid black;">Nombre(s)</th>
            <th rowspan="2" style="width:5px; border:1px solid black;"><p class="anchoCell">Género</p></th>
            <th rowspan="2" style="width:5px; border:1px solid black;"><p class="anchoCell">Ocupación</p></th>
            <th rowspan="2" style="width:60px; padding:5px; border:1px solid black;">Documento de Identidad</th>
            <th rowspan="2" style="width:60px; border:1px solid black;">Fecha de Ingreso al Servicio (1)</th>
            <th colspan="2" style="width:60px; padding:5px; border:1px solid black;">Periodo de uso del dosímetro</th>
            <th rowspan="2" style="width:50px; border:1px solid black;"><p class="verticalText">Período de recambio</p></th>
            <th rowspan="2" style="width:50px; border:1px solid black;"><p class="verticalText">Ubicación <br> del  <br> dosímetro</p></th>
            <th rowspan="2" style="width:50px; border:1px solid black;"><p class="verticalText">Energía ó calidad de radiación</p></th>
            <th colspan="3" style="width:120px; padding:5px; border:1px solid black;">Dosis del Período<br>(mSv)</th>
            <th colspan="3" style="width:120px; padding:5px; border:1px solid black;">Dosis acumulada 12 meses anteriores (mSv)</th>
            <th colspan="3" style="width:120px; padding:5px; border:1px solid black;">Dosis acumulada desde ingreso al servicio (mSv)</th>
            <th rowspan="2" style="width:50px; border:1px solid black;">Nota</th>
        </tr>
        <tr align="center">
            <th style="width:50px; padding:5px; border:1px solid black;">Primer Día</th>
            <th style="width:50px; padding:5px; border:1px solid black;">Último Día</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(10)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(0.07)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(3)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(10)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(0.07)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(3)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(10)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(0.07)</th>
            <th style="width:30px; padding:5px; border:1px solid black;">Hp(3)</th>
        </tr>
    </thead>
    <tbody style="color:#2646FA;">
        
        <?php if($dosicontrolasig->isEmpty()): ?>
            
            <?php $__currentLoopData = $trabajdosiasig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dositrabj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-left:1px solid black; border-right:1px solid black;" align="center"><?php echo e($dositrabj->dosimetro->codigo_dosimeter); ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; padding-left:3px; border:0.1px solid black;"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->primer_apellido_persona); ?> <?php echo e($dositrabj->persona->segundo_apellido_persona); ?> <?php endif; ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; padding-left:3px; border:0.1px solid black;"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->primer_nombre_persona); ?> <?php echo e($dositrabj->persona->segundo_nombre_persona); ?> <?php endif; ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->genero_persona == 'FEMENINO' ? 'F' : 'M'); ?><?php endif; ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center"><?php echo e($dositrabj->ocupacion); ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->cedula_persona); ?> <?php endif; ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center">
                        <?php $__currentLoopData = $fechainiciodositrabaj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $ckek = 0;
                            ?>
                            <?php if($dositrabj->persona_id == $fec->persona_id && $chek != $fec->persona_id): ?>
                                <?php
                                
                                    $datefix = date('d-m-Y',strtotime($fec->primer_dia_uso));
                                    $chek = $fec->persona_id;
                                    echo $datefix;
                                ?>
                                
                            <?php else: ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                        <?php
                            $datefix = date('d-m-Y',strtotime($dositrabj->primer_dia_uso));
                        ?>
                        <?php echo e($datefix); ?>

                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                        <?php
                            $datefix = date('d-m-Y',strtotime($dositrabj->ultimo_dia_uso));
                        ?>
                        <?php echo e($datefix); ?>

                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                        <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($cont->periodo_recambio); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                        <?php echo e($dositrabj->ubicacion); ?>

                        
                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center"><?php echo e($dositrabj->energia); ?></td>

                    <!--  /////////DOSIS DEL PERIODO///// -->
                    <td id ="hp10_trabjasig" style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; <?php if(($dositrabj->Hp10_calc_dose >= 12.0)): ?> color: #ff0000;  <?php endif; ?> " align="center">
                        <?php if($dositrabj->DNL =='TRUE'): ?>
                            <?php echo e('DNL'); ?>

                        <?php elseif($dositrabj->EU == 'TRUE'): ?>
                            <?php echo e('EU'); ?>

                        <?php elseif($dositrabj->DPL == 'TRUE'): ?>
                            <?php echo e('DPL'); ?>

                        <?php elseif($dositrabj->DSU == 'TRUE'): ?>
                            <?php echo e('DSU'); ?>

                        <?php elseif($dositrabj->nota2 == 'TRUE'): ?>
                            <?php echo e('NP'); ?>

                        <?php elseif($dositrabj->ubicacion == 'CRISTALINO' || $dositrabj->ubicacion == 'MUÑECA' || $dositrabj->ubicacion == 'DEDO'): ?> 
                            <?php echo e('NA'); ?>

                        <?php elseif($dositrabj->Hp10_calc_dose<= 0.1): ?>
                            <?php echo e("ND"); ?>

                        <?php else: ?> 
                            <?php echo e($dositrabj->Hp10_calc_dose); ?> 
                        <?php endif; ?>
                    </td>
                    <td id="hp007_trabjasig" style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; <?php if(($dositrabj->Hp007_calc_dose >= 12.0)): ?> color: #ff0000;  <?php endif; ?>" align="center">
                        <?php if($dositrabj->DNL =='TRUE'): ?>
                            <?php echo e('DNL'); ?>

                        <?php elseif($dositrabj->EU == 'TRUE'): ?>
                            <?php echo e('EU'); ?>

                        <?php elseif($dositrabj->DPL == 'TRUE'): ?>
                            <?php echo e('DPL'); ?>

                        <?php elseif($dositrabj->DSU == 'TRUE'): ?>
                            <?php echo e('DSU'); ?>

                        <?php elseif($dositrabj->nota2 == 'TRUE'): ?>
                            <?php echo e('NP'); ?>

                        <?php elseif($dositrabj->ubicacion == 'CRISTALINO'): ?> 
                            <?php echo e('NA'); ?> 
                        <?php elseif($dositrabj->Hp007_calc_dose <= 0.1): ?>  
                            <?php echo e("ND"); ?>

                        <?php else: ?>
                            <?php echo e($dositrabj->Hp007_calc_dose); ?> 
                        <?php endif; ?>
                    </td>
                    <td id="hp3_trabjasig" style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;  <?php if(($dositrabj->Hp3_calc_dose >= 12.0)): ?> color: #ff0000;  <?php endif; ?>" align="center">
                        <?php if($dositrabj->DNL =='TRUE'): ?>
                            <?php echo e('DNL'); ?>

                        <?php elseif($dositrabj->EU == 'TRUE'): ?>
                            <?php echo e('EU'); ?>

                        <?php elseif($dositrabj->DPL == 'TRUE'): ?>
                            <?php echo e('DPL'); ?>

                        <?php elseif($dositrabj->DSU == 'TRUE'): ?>
                            <?php echo e('DSU'); ?>

                        <?php elseif($dositrabj->nota2 == 'TRUE'): ?>
                            <?php echo e('NP'); ?> 
                        <?php elseif($dositrabj->ubicacion == 'MUÑECA'|| $dositrabj->ubicacion == 'DEDO'): ?>
                            <?php echo e('NA'); ?>

                        <?php elseif($dositrabj->Hp3_calc_dose <= 0.1): ?>
                            <?php echo e('ND'); ?>

                        <?php else: ?>
                            <?php echo e($dositrabj->Hp3_calc_dose); ?>

                        <?php endif; ?>
                    </td>

                    <!-- ///////DOSIS ACUMULADA 12 MESES ANTERIORES/////// -->
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                        <?php
                            $sumaHp10calcdose = 0;
                        ?>
                        <?php $__currentLoopData = $trabajadoresaisgxmeses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesesdositrab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php for($i=0; $i< count($mesesdositrab); $i++): ?>
                                <?php if($dositrabj->persona->id_persona == $mesesdositrab[$i]->persona_id): ?>
                                    
                                    <?php
                                        $sumaHp10calcdose += $mesesdositrab[$i]->Hp10_calc_dose;
                                    ?>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e(($sumaHp10calcdose == '') ? 0.0 : $sumaHp10calcdose); ?>

                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                        <?php
                            $sumaHp007calcdose = 0;
                        ?>
                        <?php $__currentLoopData = $trabajadoresaisgxmeses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesesdositrab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php for($i=0; $i< count($mesesdositrab); $i++): ?>
                                <?php if($dositrabj->persona->id_persona == $mesesdositrab[$i]->persona_id): ?>
                                    <?php
                                        $sumaHp007calcdose += $mesesdositrab[$i]->Hp007_calc_dose;
                                    ?>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($sumaHp007calcdose); ?>

                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center">
                        <?php
                            $sumaHp3calcdose = 0;
                        ?>
                        <?php $__currentLoopData = $trabajadoresaisgxmeses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesesdositrab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php for($i=0; $i< count($mesesdositrab); $i++): ?>
                                <?php if($dositrabj->persona->id_persona == $mesesdositrab[$i]->persona_id): ?>
                                    <?php
                                        $sumaHp3calcdose += $mesesdositrab[$i]->Hp3_calc_dose;
                                    ?>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($sumaHp3calcdose); ?>

                    </td>

                    <!-- //////////DOSIS ACUMULADA DESDE INGRESO AL SERVICIO//////// -->
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;"></td>
                    
                    <!-- //////////NOTAS//////// -->
                    <td  style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center">
                    
                            
                        <?php for($i=1; $i<=6; $i++): ?>
                            <?php if($dositrabj->{"nota$i"} == 'TRUE'): ?>
                                <?php echo e($i); ?>)
                            <?php endif; ?> 
                        <?php endfor; ?>
                    </td>    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        
        <?php else: ?>
            <?php $__currentLoopData = $dosicontrolasig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosicontrol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr align="center">
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-left:1px solid black; border-right:1px solid black;"><?php echo e($dosicontrol->codigo_dosimeter); ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">CONTROL</td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">NA</td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">NA</td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"><?php echo e($dosicontrol->ocupacion); ?></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">NA</td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;">NA</td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">
                        <?php
                            $datefix = date('d-m-Y',strtotime($dosicontrol->primer_dia_uso));
                        ?>
                        <?php echo e($datefix); ?>

                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">
                        <?php
                            $datefix = date('d-m-Y',strtotime($dosicontrol->ultimo_dia_uso));
                        ?>
                        <?php echo e($datefix); ?>

                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">
                        <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($cont->periodo_recambio); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">CONTROL</td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;"><?php echo e($dosicontrol->energia); ?></td>
                    
                    <!--  /////////DOSIS DEL PERIODO///// -->
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">
                        <?php if($dosicontrol->nota2 == 'TRUE'): ?>
                            <?php echo e('NP'); ?>

                        <?php else: ?>
                            <?php echo e($dosicontrol->Hp10_calc_dose); ?>

                        <?php endif; ?>
                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;">
                        <?php if($dosicontrol->nota2 == 'TRUE'): ?>
                            <?php echo e('NP'); ?>

                        <?php else: ?>
                            <?php echo e($dosicontrol->Hp007_calc_dose); ?>

                        <?php endif; ?>
                    </td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;">
                         
                        <?php echo e($dosicontrol->Hp3_calc_dose); ?>

                    </td>

                    <!-- ///////DOSIS ACUMULADA 12 MESES ANTERIORES/////// -->
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;"></td>

                    <!-- //////////DOSIS ACUMULADA DESDE INGRESO AL SERVICIO//////// -->
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                    <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;"></td>

                    <!-- //////////NOTAS//////// -->
                    <td  style="padding-top:5px; padding-bottom:5px; border-right:1px solid black;">
                        <?php for($i=1; $i<=6; $i++): ?>
                            <?php if($dosicontrol->{"nota$i"} == 'TRUE'): ?>
                                <?php echo e($i); ?>)
                            <?php endif; ?> 
                        <?php endfor; ?>
                    </td>
                </tr>
                
            
                <?php $__currentLoopData = $trabajdosiasig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dositrabj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-left:1px solid black; border-right:1px solid black;" align="center"><?php echo e($dositrabj->dosimetro->codigo_dosimeter); ?></td>
                        <td style="padding-top:5px; padding-bottom:5px; padding-left:3px; border:0.1px solid black;"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->primer_apellido_persona); ?> <?php echo e($dositrabj->persona->segundo_apellido_persona); ?> <?php endif; ?></td>
                        <td style="padding-top:5px; padding-bottom:5px; padding-left:3px; border:0.1px solid black;"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->primer_nombre_persona); ?> <?php echo e($dositrabj->persona->segundo_nombre_persona); ?> <?php endif; ?></td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->genero_persona == 'FEMENINO' ? 'F' : 'M'); ?> <?php endif; ?></td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center"><?php echo e($dositrabj->ocupacion); ?></td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center"><?php if($dositrabj->persona_id == NULL): ?> <?php else: ?> <?php echo e($dositrabj->persona->cedula_persona); ?> <?php endif; ?></td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center">
                            <?php $__currentLoopData = $fechainiciodositrabaj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $ckek = 0;
                                ?>
                                <?php if($dositrabj->persona_id == $fec->persona_id && $chek != $fec->persona_id): ?>
                                    <?php
                                    
                                        $datefix = date('d-m-Y',strtotime($fec->primer_dia_uso));
                                        $chek = $fec->persona_id;
                                        echo $datefix;
                                    ?>
                                    
                                <?php else: ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                            <?php
                                $datefix = date('d-m-Y',strtotime($dositrabj->primer_dia_uso));
                            ?>
                            <?php echo e($datefix); ?>

                        </td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                            <?php
                                $datefix = date('d-m-Y',strtotime($dositrabj->ultimo_dia_uso));
                            ?>
                            <?php echo e($datefix); ?>

                        </td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                            <?php $__currentLoopData = $contratoDosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($cont->periodo_recambio); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                            <?php echo e($dositrabj->ubicacion); ?>

                            
                        </td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center"><?php echo e($dositrabj->energia); ?></td>

                        <!--  /////////DOSIS DEL PERIODO///// -->
                        <td id ="hp10_trabjasig" style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; <?php if(($dositrabj->Hp10_calc_dose - $dosicontrol->Hp10_calc_dose >= 12.0)): ?> color: #ff0000;  <?php endif; ?> " align="center">
                            <?php if($dositrabj->DNL =='TRUE'): ?>
                                <?php echo e('DNL'); ?>

                            <?php elseif($dositrabj->EU == 'TRUE'): ?>
                                <?php echo e('EU'); ?>

                            <?php elseif($dositrabj->DPL == 'TRUE'): ?>
                                <?php echo e('DPL'); ?>

                            <?php elseif($dositrabj->DSU == 'TRUE'): ?>
                                <?php echo e('DSU'); ?>

                            <?php elseif($dositrabj->nota2 == 'TRUE'): ?>
                                <?php echo e('NP'); ?>

                            <?php elseif($dositrabj->ubicacion == 'CRISTALINO' || $dositrabj->ubicacion == 'MUÑECA' || $dositrabj->ubicacion == 'DEDO'): ?> 
                                <?php echo e('NA'); ?>

                            <?php elseif($dositrabj->Hp10_calc_dose - $dosicontrol->Hp10_calc_dose <= 0.1): ?>
                                <?php echo e("ND"); ?>

                            <?php else: ?> 
                                <?php echo e($dositrabj->Hp10_calc_dose - $dosicontrol->Hp10_calc_dose); ?> 
                            <?php endif; ?>
                        </td>
                        <td id="hp007_trabjasig" style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; <?php if(($dositrabj->Hp007_calc_dose - $dosicontrol->Hp007_calc_dose >= 12.0)): ?> color: #ff0000;  <?php endif; ?>" align="center">
                            <?php if($dositrabj->DNL =='TRUE'): ?>
                                <?php echo e('DNL'); ?>

                            <?php elseif($dositrabj->EU == 'TRUE'): ?>
                                <?php echo e('EU'); ?>

                            <?php elseif($dositrabj->DPL == 'TRUE'): ?>
                                <?php echo e('DPL'); ?>

                            <?php elseif($dositrabj->DSU == 'TRUE'): ?>
                                <?php echo e('DSU'); ?>

                            <?php elseif($dositrabj->nota2 == 'TRUE'): ?>
                                <?php echo e('NP'); ?>

                            <?php elseif($dositrabj->ubicacion == 'CRISTALINO'): ?> 
                                <?php echo e('NA'); ?> 
                            <?php elseif($dositrabj->Hp007_calc_dose - $dosicontrol->Hp007_calc_dose  <= 0.1): ?>  
                                <?php echo e("ND"); ?>

                            <?php else: ?>
                                <?php echo e($dositrabj->Hp007_calc_dose - $dosicontrol->Hp007_calc_dose); ?> 
                            <?php endif; ?>
                        </td>
                        <td id="hp3_trabjasig" style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;  <?php if(($dositrabj->Hp3_calc_dose - $dosicontrol->Hp3_calc_dose >= 12.0)): ?> color: #ff0000;  <?php endif; ?>" align="center">
                            <?php if($dositrabj->DNL =='TRUE'): ?>
                                <?php echo e('DNL'); ?>

                            <?php elseif($dositrabj->EU == 'TRUE'): ?>
                                <?php echo e('EU'); ?>

                            <?php elseif($dositrabj->DPL == 'TRUE'): ?>
                                <?php echo e('DPL'); ?>

                            <?php elseif($dositrabj->DSU == 'TRUE'): ?>
                                <?php echo e('DSU'); ?>

                            <?php elseif($dositrabj->nota2 == 'TRUE'): ?>
                                <?php echo e('NP'); ?> 
                            <?php elseif($dositrabj->ubicacion == 'MUÑECA'|| $dositrabj->ubicacion == 'DEDO'): ?>
                                <?php echo e('NA'); ?>

                            <?php elseif($dositrabj->Hp3_calc_dose - $dosicontrol->Hp3_calc_dose <= 0.1): ?>
                                <?php echo e('ND'); ?>

                            <?php else: ?>
                                <?php echo e($dositrabj->Hp3_calc_dose - $dosicontrol->Hp3_calc_dose); ?>

                            <?php endif; ?>
                        </td>

                        <!-- ///////DOSIS ACUMULADA 12 MESES ANTERIORES/////// -->
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                            <?php
                                $sumaHp10calcdose = 0;
                            ?>
                            <?php $__currentLoopData = $trabajadoresaisgxmeses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesesdositrab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php for($i=0; $i< count($mesesdositrab); $i++): ?>
                                    <?php if($dositrabj->persona->id_persona == $mesesdositrab[$i]->persona_id): ?>
                                        
                                        <?php
                                            $sumaHp10calcdose += $mesesdositrab[$i]->Hp10_calc_dose;
                                        ?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e(($sumaHp10calcdose == '') ? 0.0 : $sumaHp10calcdose); ?>

                        </td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;" align="center">
                            <?php
                                $sumaHp007calcdose = 0;
                            ?>
                            <?php $__currentLoopData = $trabajadoresaisgxmeses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesesdositrab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php for($i=0; $i< count($mesesdositrab); $i++): ?>
                                    <?php if($dositrabj->persona->id_persona == $mesesdositrab[$i]->persona_id): ?>
                                        <?php
                                            $sumaHp007calcdose += $mesesdositrab[$i]->Hp007_calc_dose;
                                        ?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($sumaHp007calcdose); ?>

                        </td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center">
                            <?php
                                $sumaHp3calcdose = 0;
                            ?>
                            <?php $__currentLoopData = $trabajadoresaisgxmeses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesesdositrab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php for($i=0; $i< count($mesesdositrab); $i++): ?>
                                    <?php if($dositrabj->persona->id_persona == $mesesdositrab[$i]->persona_id): ?>
                                        <?php
                                            $sumaHp3calcdose += $mesesdositrab[$i]->Hp3_calc_dose;
                                        ?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($sumaHp3calcdose); ?>

                        </td>

                        <!-- //////////DOSIS ACUMULADA DESDE INGRESO AL SERVICIO//////// -->
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black;"></td>
                        <td style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;"></td>
                        
                        <!-- //////////NOTAS//////// -->
                        <td  style="padding-top:5px; padding-bottom:5px; border:0.1px solid black; border-right:1px solid black;" align="center">
                            <?php for($i=1; $i<=6; $i++): ?>
                                <?php if($dositrabj->{"nota$i"} == 'TRUE'): ?>
                                    <?php echo e($i); ?>)
                                <?php endif; ?> 
                            <?php endfor; ?>
                        </td>   
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>




    <div style="position:absolute; top:600px; border:solid 0.1px #000; width: 1255px;  height:35px; padding:5px 5px 5px 5px;">
        <p style="text-align:justify; margin:0px;">
            <b>NOMENCLATURA:</b> <b>NA =</b> No Aplica (No se tiene observaciones), <b>ND =</b> Dosis No Detectable (Significa que la lectura esta entre cero y el umbral de detección=0,1 mSv), 
            <b>NP =</b> Dosímetro No Presentado (No se llegó el dosímetro a las instalaciones de QA POSITRON), <b>DNL =</b> Dosímetro No Legible (Dosímetro llegó, pero no se puede leer por deterioro), 
            <b>EU =</b> Dosímetro en Uso (el dosímetro está en uso por el usuario), <b>DPL =</b> Dosímetro en Proceso de Lectura (El dosímetro llegó a las instalaciones y no se ha procesado la lectura), 
            <b>DSU =</b> Dosímetro sin usar (Dosímetro que indica el cliente que no se usó en ese periodo)
        </p> 
        
    </div>
    <div style="position:absolute; top:645px; border:solid 0.1px #000; width: 1255px;  height:25px; padding:5px 5px 5px 5px;">
        <p style="text-align:justify; margin:0px;">
            
            <b>NOTAS:</b> <b>1 =</b> Ninguna (No se tiene ninguna nota), <b>2 =</b> Extraviado (No llegó el dosímetro a nuestras instalaciones y se declara extraviado), <b> 3 =</b> Supera dosis permitida de 1,67 mSv (Tórax), 41,6 mSv (Anillo) y 12,5 mSv (Cristalino) (La lectura indica que superó el nivel de dosis permitido para un periodo mensual), <b>4 =</b> Dosímetro reprocesado (Se realiza segunda lectura a petición del usuario), <b>5 =</b> Control no utilizado en la evaluación (Lectura del dosímetro de Control, no restada en la evaluación), <b>6 =</b> Dosímetro contaminado por material radioactivo.
        </p>
    </div>
    <p style="position:absolute; top:680px; border:solid 0.1px #000; width: 1255px; height:25px; padding:5px 5px 5px 5px; text-align:justify; margin:0px;">
        <b>(1)</b> En el caso que usuario haya sido desactivado y reactivado posteriormente, la fecha indicada en este campo será la de la última reactivación. Este ajuste no implica  cambio en el histórico de dosis. En caso de necesitar cualquier aclaración respecto a la información aquí dispuesta favor hacer la consulta al correo electrónico <b>dosimetria.qapositron@gmail.com</b> 
    </p>



<!-- ////////////////////////////////////----------------SEGUNDA PAGINA------------//////////////////////////////////////////////7 -->
<div style="position:absolute; width: 100%; page-break-before: always;">
    <p style="text-align:justify; border:solid 0.3px #000; width: 1255px; padding:5px 5px 5px 5px; margin:0px;"> 
        <b> INFORMACIÓN DE INTERÉS GENERAL: </b> <br>
            <b>i.</b>   Hp(d), es la dosis equivalente personal a la profundidad indicada en milímetros. Así: Hp(10) estima la dosis en tejido profundo a 10mm de profundidad, Hp(3) estima la dosis al cristalino a 3mm de profundidad, y Hp(0.07) estima la dosis en tejido superficial (extremidades y piel o poco profundo) a 0,07mm de profundidad. <br>
            <b>ii.</b>  Los dosímetros de control, tienen por objeto la verificación de irradiaciones incidentales o accidentales durante el transporte y/o lugar de almacenamiento mientras es retornado para lectura. No deben utilizarse o ser asignados a usuario. <br>
            <b>iii.</b> Toda dosis que supere el valor de 1.67 mSv/mes debe ser investigada y documentada al interior de la instalación. Tal registro, es una señal de alerta indicadora de la posibilidad de sobrepasar el límite anual, o indicadora de la necesidad de optimizar la práctica. <br>
            <b>iv.</b>  Toda dosis que supere el valor de 12.0 mSv/mes debe ser inmediatamente reportada a la Autoridad Reguladora, con el fin de emprender acciones que reduzcan o eviten la exposición o la probabilidad de exposición. <br>
            <b>v.</b>       La periodicidad de recambio de los dosímetros, reviste importancia ante la necesidad de investigar registros de dosis fuera de los rangos recomendados, ante un incidente, un accidente o una situación de emergencia <br>
    </p>
    <p style="text-align:justify; border:solid 0.3px #000; width: 1255px; padding:5px 5px 5px 5px; margin:0px;"> 
        <b>INFORMACIÓN DEL REPORTE DE EXPOSICIÓN:</b> <br>
            Nombre(s) y Apellido(s): identificando la persona a la cual el dosímetro es asignado. Género (M=Masculino, F=Femenino); Documento de Identidad. Fecha de Ingreso al Servicio: corresponde a la fecha en que QA POSITRON empezó a mantener registros de dosimetría para un participante en la cuenta actual, o de la última reactivación del servicio, de aplicar.
            Ocupación: de acuerdo con la información suministrada por la entidad contratante, se clasifica la ocupación con la siguiente nomenclatura: <b>T =</b> Teleterapia, <b>BQ =</b> Braquiterapia, <b>MN =</b> Medicina Nuclear, <b>GI =</b> Gammagrafía industrial, <b>MF =</b> Medidores fijos, <b>IV =</b> Investigación, <b>DN =</b> Densímetro nuclear, <b>MM =</b> Medidores móviles, <b>E =</b> Docencia, <b>PR =</b> Perfilaje y registro, <b>TR =</b> Trazadores, <b>HD =</b> Hemodinamia, <b>OD =</b> Rayos x odontológico, <b>RX =</b> Radiodiagnóstico, <b>FL =</b> Fluoroscopia, <b>AM =</b> Aplicaciones Médicas, <b>AI =</b> Aplicaciones Industriales.
            Periodo de uso del Dosímetro: se relaciona la fecha asignada para inicio y terminación del periodo de medición, la cual es correspondiente con la marcación del dosímetro de acuerdo a la solicitud del cliente. Periodo de recambio: se refiere a la frecuencia de cambio en términos de M=Mes o T=Trimestre.

    </p>
    <div style="text-align:justify; border:solid 0.3px #000; width: 1255px; height:160px; padding:5px 5px 5px 5px; margin:0px;">
        <p style="padding:5px 5px 5px 5px; margin:0px;">
            <b>UBICACIÓN DEL DOSÍMETRO:</b><br>
            Se refiere al uso o localización en el cuerpo, para la cual el dosímetro es suministrado.
        </p> 
        <br>
        <table style="top:220px; text-align:center;" border="1">
            <thead>
                <tr>
                    <th style= "">UBICACIÓN DOSÍMETRO</th>
                    <th style= "width: 35px;">USO</th>
                    <th style= "width: 35px;">TIPO</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>ÁREA</td>
                    <td>Monitor Ambiental</td>
                    <td>OSL</td>
                </tr>
                <tr>
                    <td>TÓRAX</td>
                    <td>Cuerpo Entero</td>
                    <td>OSL</td>
                </tr>
                <tr>
                    <td>CONTROL</td>
                    <td>Control en transporte y almacenamiento</td>
                    <td>OSL</td>
                </tr>
                <tr>
                    <td>CRISTALINO</td>
                    <td>Lente de Ojo</td>
                    <td>OSL</td>
                </tr>
                <tr>
                    <td>DEDO</td>
                    <td>Extremidad</td>
                    <td>OSL</td>
                </tr>
                <tr>
                    <td>MUÑECA</td>
                    <td>Extremidad</td>
                    <td>OSL</td>
                </tr>
                <tr>
                    <td>CASO</td>
                    <td>La que indique la institución</td>
                    <td>OSL</td>
                </tr>
            </tbody>
            
        </table>
        <br>
    </div>
    <p style="text-align:justify; border:solid 0.3px #000; width: 1255px; padding:5px 5px 5px 5px; margin:0px;"> 
        <b>OBSERVACIONES DEL PERIODO:</b> <br>
            En este informe se encuentran los reportes de dosis de radiación correspondientes al periodo comprendido entre: 
            
            <?php $__currentLoopData = $trabajdosiasig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dositrabj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $datefix = date('d-m-Y',strtotime($dositrabj->primer_dia_uso));
                    $datefix2 = date('d-m-Y',strtotime($dositrabj->ultimo_dia_uso));
                ?>
                <b><?php echo e($datefix); ?> y <?php echo e($datefix2); ?></b> 
                <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br>
            <?php if(!empty($dosicontrolasig)): ?>
                -   Se analizaron <?php echo e(count($trabajdosiasig)); ?> dosímetros personales y <?php echo e(count($dosicontrolasig)); ?> dosímetros de control.
            <?php else: ?>
                -   Se analizaron <?php echo e(count($trabajdosiasig)); ?> dosímetros personales.
            <?php endif; ?>
            <br>
            <?php if(!empty($mesescantdosi)): ?>
                <?php $__currentLoopData = $mesescantdosi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesesobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($mesesobs->nota_cambiodosim != null): ?>
                        - <?php echo e($mesesobs->nota_cambiodosim); ?> <br>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php $__currentLoopData = $trabajdosiasig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dositrabj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($dositrabj->nota3 == 'TRUE'): ?>
                    - Se recomienda revisar el límite de las dosis permitidas.
                    <br>
                <?php endif; ?>
                <?php if($dositrabj->nota5 == 'TRUE'): ?>
                    - Control no utilizado en la evaluación.
                    <br>
                <?php endif; ?>
                <?php if($dositrabj->nota6 == 'TRUE'): ?>
                    - Dosímetro contaminado con material radioactivo, se recomienda hacer investigación.
                    <br>
                <?php endif; ?>
                <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
    </p>
</div>



    <!-- ////////////////////SCRIPT PARA CONTAR LAS PAGINAS/////////////// -->
    <script type="text/php">
        if (isset($pdf)) {
            $text = "página {PAGE_NUM} de {PAGE_COUNT}";
            $size = 8;
            $font = $fontMetrics->getFont("Verdana");
            $width = $fontMetrics->get_text_width($text, $font, $size) / 2;
            $x = ($pdf->get_width() - $width) / 2;
            $y = $pdf->get_height() - 40;
            $pdf->page_text($x, $y, $text, $font, $size);
        }
    </script>
<script
src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous">
</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
    $(window).load(function() {
        $(".loader").fadeOut("slow");
    });

    $(document).ready(function(){
        $('#hp10_trabjasig').on('change', function(){
            var hp10 = document.getElementById("hp10_trabjasig");
            console.log(hp10);
        })
    })
</script>


</body>
<?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/dosimetria/reportePDF_dosimetria.blade.php ENDPATH**/ ?>