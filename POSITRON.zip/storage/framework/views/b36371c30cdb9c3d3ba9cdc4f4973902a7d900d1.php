

<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col"></div>
        <div class="col-6">
            <div class="card text-dark bg-light" >
                <h2 class="text-center mt-3">EDITAR SEDE</h2>

                <form class="m-4" id='form_edit_sede' name='form_edit_sede' action="<?php echo e(route('sedes.update', $sede)); ?>" method="POST">
                
                    <?php echo csrf_field(); ?>

                    <?php echo method_field('put'); ?>

                    <div class="row g-2">
                        <h6 class="text-center">OBSERVE LAS ESPECIALIDADES EN LA SEDE Y AÑADA LA QUE DESEE </h6>
                        <div class="col"></div>
                        <div class="col-5 ">
                            <div class="table table-responsive">
                                <table class="table table-bordered">
                                    
                                    <tbody>
                                        <?php $__currentLoopData = $deptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-center">
                                                <td><?php echo e($dep->departamento->nombre_departamento); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col"></div>
                    </div>
                    <div class="row g-2">
                        <div class="col-10">
                            <label for=""> AÑADIR ESPECIALIDADES:

                            </label>
                            <div class="form-floating">
                                <select class="form-select <?php $__errorArgs = ['multiple_select_depsede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="multiple_select_depsede" name="multiple_select_depsede[]" autofocus aria-label="Floating label select example" multiple="true">
                                    <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dep->id_departamento); ?>" <?php echo e(in_array($dep->id_departamento, (array) old('multiple_select_depsede', [])) ? "selected" : ""); ?>><?php echo e($dep->nombre_departamento); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['multiple_select_depsede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>    
                        </div>
                        <div class="col-md mt-4">
                            <div class="col-md d-flex align-items-center ">
                                <button type="button" class="btn colorQA" data-bs-toggle="modal" data-bs-target="#nuevo_deptoModal" >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
                                        <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="row g-2">
                        <div class="col-md">
                            <div class="form-floating text-wrap">
                                <input type="text" class="form-control"   name="empresas_id" id="empresas_id" value="<?php echo e(old('empresas_id', $sede->empresa->nombre_empresa)); ?>" autofocus style="text-transform:uppercase;" disabled>
                                <input type="text" class="form-control <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"   name="id_empresa" id="id_empresa" value="<?php echo e(old('id_empresa', $sede->empresa->id_empresa)); ?>" autofocus style="text-transform:uppercase;" hidden>
                                <label for="floatingSelectGrid">EMPRESA:</label>
                                <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md">
                            <div class="form-floating text-wrap">
                                <input type="text" class="form-control <?php $__errorArgs = ['nombre_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="nombre_sede" id="nombre_sede" value="<?php echo e(old('nombre_sede', $sede->nombre_sede)); ?>" autofocus style="text-transform:uppercase;">
                                <label for="floatingInputGrid">NOMBRE DE LA SEDE:</label>
                                <?php $__errorArgs = ['nombre_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="row g-2">
                        <div class="col-md">
                            <div class="form-group">
                                <label for="floatingInputGrid">DEPARTAMENTO:</label>
                                <select class="form-control <?php $__errorArgs = ['departamento_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="departamento_sede" id="departamento_sede" value="<?php echo e(old('departamento_sede')); ?>" autofocus style="text-transform:uppercase">
                                    <option value="<?php echo e($sede->municipios->coldepartamento->id_departamentocol); ?>">--<?php echo e($sede->municipios->coldepartamento->nombre_deptocol); ?>--</option>
                                    <?php $__currentLoopData = $departamentoscol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depacol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($depacol->id_departamentocol); ?>" <?php if(old('departamento_sede') == $depacol->id_departamentocol): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($depacol->nombre_deptocol); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['departamento_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md" id="div_municipio">
                            <div class="spinner_municipio text-center" id="spinner_municipio">

                            </div>
                            <div class="form-group" id="municipio_empresa" name="municipio_empresa">
                                <label for="floatingInputGrid">MUNICIPIO:</label>
                                <select class="form-control <?php $__errorArgs = ['municipio_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="municipio_sede" id="municipio_sede" value="<?php echo e(old('municipio_sede')); ?>" autofocus style="text-transform:uppercase">
                                    <option value="<?php echo e($sede->municipios->id_municipiocol); ?>">--<?php echo e($sede->municipios->nombre_municol); ?>--</option>
                                </select>
                                <?php $__errorArgs = ['municipio_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="row g-2">
                        <div class="col-md">
                            <div class="form-floating text-wrap">
                                <input type="text" name="direccion_sede" id="direccion_sede" class="form-control <?php $__errorArgs = ['direccion_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('direccion_sede', $sede->direccion_sede)); ?>" autofocus style="text-transform:uppercase;">
                                <label for="">DIRECCIÓN:</label>
                                <?php $__errorArgs = ['direccion_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <br>
                    
                    <div class="row">
                        <div class="col"></div>
                        <div class="col d-grid gap-2">
                            <button class="btn colorQA" type="submit" id="boton-guardar" name="boton-guardar">ACTUALIZAR</button>
                        </div>
                        <div class="col d-grid gap-2">
                            <a href="<?php echo e(route('empresas.search')); ?>" class="btn btn-danger" type="button" id="cancelar" name="cancelar" role="button">CANCELAR</a>
                        </div>
                        <div class="col"></div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col"></div>    
    </div>

    <div class="modal fade" id="nuevo_deptoModal" tabindex="-1" aria-labelledby="nuevo_deptoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center" id="nuevo_deptoModalLabel">NUEVA ESPECIALIDAD</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form-departamento')->html();
} elseif ($_instance->childHasBeenRendered('yZFWSZ1')) {
    $componentId = $_instance->getRenderedChildComponentId('yZFWSZ1');
    $componentTag = $_instance->getRenderedChildComponentTagName('yZFWSZ1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yZFWSZ1');
} else {
    $response = \Livewire\Livewire::mount('form-departamento');
    $html = $response->html();
    $_instance->logRenderedChild('yZFWSZ1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div> 
        </div>
    </div>
<script
src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous">
</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script> 


<?php if(session('guardar')== 'ok'): ?>
    <script>
        Swal.fire(
        'GUARDADO!',
        'SE HA GUARDADO CON ÉXITO.',
        'success'
        )
    </script>
<?php endif; ?>

<script type="text/javascript">
    $(document).ready(() => {

        $('#multiple_select_depsede').select2({
            placeholder:"SELECCIONE LAS ESPECIALIDADES",
            tags: true,
            tokenSeparators: ['/',',',',',','," "]
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#departamento_sede').select2();
        $('#municipio_sede').select2();
    });
</script> 
    
<script type="text/javascript">
    $(document).ready(function() {
        $('#departamento_sede').on('change', function(){
            $('#municipio_empresa').fadeOut();
            $('#spinner_municipio').html('<div class="spinner-border text-secondary" id="spinner" role="status"></div>');
            var departamento_id = $(this).val();
            alert(departamento_id);
            var padre = document.getElementById("spinner_municipio");
            var hijo = document.getElementById("spinner");
            if($.trim(departamento_id) != ''){
                $.get('empresasdeptomuni', {departamento_id: departamento_id}, function(municipios){
                    console.log(municipios);
                    var remove = padre.removeChild(hijo);
                    $('#municipio_empresa').fadeIn();
                    $('#municipio_sede').empty();
                    $('#municipio_sede').append("<option value='<?php echo e($sede->municipios->id_municipiocol); ?>'>--<?php echo e($sede->municipios->nombre_municol); ?>--</option>");
                    $.each(municipios, function(index, value){
                        $('#municipio_sede').append("<option value='"+ index + "'>" + value + "</option>");
                    })
                });
            }
        });
    });
</script>


<script type="text/javascript">
    function eliminarDepto(depto, sede){
        var departamento = depto;
        var sed = sede;
        
            $.get('destroydepto', {departamento: departamento, sed: sed}, function(respuesta){
                console.log(respuesta);
                
            });
    }
</script>



<script type="text/javascript">
$(document).ready(function(){
    $('#form_edit_sede').submit(function(e){
        e.preventDefault();
        Swal.fire({
            text: 'SEGURO QUE DESEA ACTUALIZAR LA INFORMACIÓN DE ESTA SEDE?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1A9980',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
               
                this.submit(); 
            }
        })
    });
    $('#form_crear_depto').submit(function(e){
        e.preventDefault();
        Swal.fire({
            text: "DESEA GUARDAR ESTA ESPECIALIDAD??",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
            }).then((result) => {
            if (result.isConfirmed) {
                
                this.submit();
            }
        })
    })
})
</script> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/sede/edit_sede.blade.php ENDPATH**/ ?>