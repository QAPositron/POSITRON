

<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-md">
        <a type="button" class="btn btn-circle colorQA" href="<?php echo e(route('asignadosicontrato.info', ['asigdosicont' => $dosicontasig->contdosisededepto_id, 'mesnumber' => $dosicontasig->mes_asignacion ])); ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-arrow-left mt-1" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
            </svg>
        </a>
    </div>
    <div class="col-md-6">
        <h3 class="text-center">EDITAR LA LECTURA DEL DOSÍMETRO TIPO CONTROL </h3>
        <h3 class="text-center">ESPECIALIDAD: <?php echo e($dosicontasig->contratodosimetriasededepto->departamentosede->nombre_departamento); ?>" - CONTRATO No. <?php echo e($dosicontasig->contratodosimetriasede->dosimetriacontrato->codigo_contrato); ?> - MES <?php echo e($dosicontasig->mes_asignacion); ?></h3>
    </div>
    <div class="col-md"></div>
</div>
<br>

<BR></BR>

<div class="row">
        <div class="col"></div>
        <div class="col-11">
            <div class="card ">
                <div class="card-header ">
                    <ul class="nav nav-tabs card-header-tabs" id="infoLectura" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" href="#infoempresa" role="tab" aria-controls="infoempresa" aria-selected="true">INFO EMPRESA</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"  href="#infocontrato" role="tab" aria-controls="infocontrato" aria-selected="false">INFO CONTRATO</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link link-danger" href="#lectura" role="tab" aria-controls="lectura" aria-selected="false">LECTURA</a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content mt-3">
                        <!-- //////////////////// PESTAÑA DE INFO EMPRESA //////////////// -->
                        <div class="tab-pane active" id="infoempresa" role="tabpanel">
                            <h4 class="card-title text-center pt-3">INFORMACIÓN DE LA EMPRESA</h4>
                            <BR></BR>
                            <Label class="mx-5">LA SIGUIENTE ES INFORMACIÓN DE LA EMPRESA QUE FUE RELACIONA AL DOSÍMETRO DE TIPO CONTROL EN EL PROCESO DE ASIGNACIÓN:</Label>
                            <BR></BR>
                            <div class="row">
                                <div class="col"></div>
                                <div class="col-md m-4">
                                    <label for="floatingInputGrid"> <b>EMPRESA:</b> </label>
                                    <input type="text"  class="form-control text-center" name="empresaLectDosimControl" id="empresaLectDosimControl" value="<?php echo e($dosicontasig->contratodosimetriasede->sede->empresa->nombre_empresa); ?>" readonly>
                                    <br>
                                    
                                </div>
                                <div class="col-md m-4">
                                    <label for="floatingInputGrid"> <b>NÚM. IDEN.:</b> </label>
                                    <input type="text" class="form-control text-center" name="numIdenEmpresaLectDosimControl" id="numIdenEmpresaLectDosimControl" value="<?php echo e($dosicontasig->contratodosimetriasede->sede->empresa->num_iden_empresa); ?>" readonly>
                                    <br>
                                   
                                </div>
                                <div class="col-md m-4">
                                    <label for="floatingInputGrid"> <b>SEDE:</b> </label>
                                    <input type="text"  class="form-control text-center" name="sedeLectDosimControl" id="sedeLectDosimControl" value="<?php echo e($dosicontasig->contratodosimetriasede->sede->nombre_sede); ?>" readonly>
                                    <br>
                                </div>
                                <div class="col-md m-4">
                                    <label for="floatingInputGrid"> <b>DEPARTAMENTO:</b> </label>
                                    <input type="text"  class="form-control text-center" name="deptoLectDosimControl" id="deptoLectDosimControl" value="<?php echo e($dosicontasig->contratodosimetriasededepto->departamentosede->nombre_departamento); ?>" readonly>
                                    <br>
                                </div>
                                <div class="col-md"></div>
                            </div>
                            <br>
                            
                        </div>
                        <!-- //////////////////// PESTAÑA DE INFO CONTRATO //////////////// -->
                        <div class="tab-pane" id="infocontrato" role="tabpanel" aria-labelledby="infocontrato-tab">
                            <h4 class="card-title text-center pt-3">INFORMACIÓN DEL CONTRATO</h4>
                            <BR></BR>
                            <Label class="mx-5">LA SIGUIENTE ES INFORMACIÓN DEL CONTRATO QUE ES RELACIONADO AL DOSÍMETRO EN EL PROCESO DE ASIGNACIÓN:</Label>
                            <BR></BR>
                            <div class="row">
                                <div class="col m-4"></div>
                                <div class="col m-4">
                                    <label for="floatingInputGrid"> <b>COD. DOSÍMETRO:</b> </label>
                                    <input type="text"  class="form-control" name="codDosimLectDosimControl" id="codDosimLectDosimControl" value="<?php echo e($dosicontasig->dosimetro->codigo_dosimeter); ?>" readonly>
                                    <br>
                                    <label for="floatingInputGrid"> <b>PRIMER DÍA USO:</b> </label>
                                    <input type="text" class="form-control" name="primDiaUsoLectDosimControl" id="primDiaUsoLectDosimControl" value="<?php echo e($dosicontasig->primer_dia_uso); ?>" readonly>
                                    <br>
                                    <label for="floatingInputGrid"> <b>OCUPACIÓN:</b> </label>
                                    <input type="text"  class="form-control" name="ocupLectDosimControl" id="ocupLectDosimControl" value="<?php echo e($dosicontasig->ocupacion); ?>" readonly>
                                </div>
                                <div class="col m-4">
                                    <label for="floatingInputGrid"> <b>TIPO DOSÍMETRO:</b></label>
                                    <input type="text"  class="form-control" name="tipoDoimLectDosimControl" id="tipoDosimLectDosimControl" value="<?php echo e($dosicontasig->dosimetro->tipo_dosimetro); ?>" readonly>
                                    <br>
                                    <label for="floatingInputGrid"> <b>ULTIMO DÍA USO:</b> </label>
                                    <input type="text"  class="form-control" name="ultDiaUsobLectDosimControl" id="ultDiaUsobLectDosimControl" value="<?php echo e($dosicontasig->ultimo_dia_uso); ?>" readonly>
                                    <br>
                                    <label for="floatingInputGrid"> <b>ENERGÍA:</b> </label>
                                    <input type="text"  class="form-control" name="energiaLectDosimControl" id="energiaLectDosimControl" value="<?php echo e($dosicontasig->energia); ?>" readonly>
                                </div>
                                <div class="col-3 m-4">
                                    <label for="floatingInputGrid"> <b>FECHA INGRESO AL SERVICIO:</b> </label>
                                    <input type="text"  class="form-control" name="FIngServLectDosimControl" id="FIngServLectDosimControl" value="<?php echo e($dosicontasig->dosimetro->fecha_ingreso_servicio); ?>" readonly>
                                    <br>
                                    <label for="floatingInputGrid"> <b>PERIODO DE RECAMBIO:</b> </label>
                                    <input type="text"  class="form-control" name="pRecamLectDosimControl" id="pRecamLectDosimControl" value="<?php echo e($dosicontasig->contratodosimetriasede->dosimetriacontrato->periodo_recambio); ?>" readonly>
                                    <br>
                                </div>
                                <div class="col"></div>
                            </div>
                            <br>
                        </div>
                        <!-- //////////////////// PESTAÑA DE LECTURA//////////////// -->
                        <div class="tab-pane" id="lectura" role="tabpanel" aria-labelledby="lectura-tab">
                            
                            <h4 class="card-title text-center">CÓDIGO DEL DOSÍMETRO: <?php echo e($dosicontasig->dosimetro->codigo_dosimeter); ?></h4>
                            <BR></BR>
                            <Label class="mx-5">MODIFIQUE LA INFORMACIÓN DE LA LECTURA DEL DOSÍMETRO ASIGNADO:</Label>
                            <BR></BR>
                            <div class="row">
                                <div class="col"></div>
                                <div class="col-10">
                                    <div class="card text-dark bg-light">
                                        <form class="m-4" id="form_edit_save_lectura_dosim" name="form_edit_save_lectura_dosim" action="<?php echo e(route('lecturadosicontrol.save', $dosicontasig )); ?>" method="POST">
                                            
                                            <?php echo csrf_field(); ?>

                                            <?php echo method_field('put'); ?>

                                            <input type="NUMBER" id="mes_asignacion" name="mes_asignacion" value="<?php echo e($dosicontasig->mes_asignacion); ?>" hidden>
                                            <input type="NUMBER" id="id_contratodosimetriasededepto" name="id_contratodosimetriasededepto" value="<?php echo e($dosicontasig->contdosisededepto_id); ?>" hidden>
                                            <div class="row g-2">
                                                <div class="col-md-4 mx-4">
                                                    <div class="form-floating">
                                                        <input type="NUMBER" step="any" class="form-control" name="hp007_calc_dose" id="hp007_calc_dose" value="<?php echo e($dosicontasig->Hp007_calc_dose); ?>">
                                                        <label for="floatingInputGrid">Hp007 CALC DOSE:</label>
                                                    </div>
                                                    <br>
                                                    <div class="form-floating">
                                                        <input type="NUMBER" step="any" class="form-control" name="hp10_calc_dose" id="hp10_calc_dose" value="<?php echo e($dosicontasig->Hp10_calc_dose); ?>">
                                                        <label for="floatingInputGrid">Hp10 CALC DOSE:</label>
                                                    </div>
                                                    <br>
                                                    <div class="form-floating">
                                                        <input type="NUMBER" step="any" class="form-control" name="hp3_calc_dose" id="hp3_calc_dose" value="<?php echo e($dosicontasig->Hp3_calc_dose); ?>">
                                                        <label for="floatingInputGrid">Hp3 CALC DOSE:</label>
                                                    </div>
                                                    <br>
                                                    <div class="form-floating">
                                                        <input type="date" class="form-control" name="measurement_date"  id="measurement_date" value="<?php echo e($dosicontasig->measurement_date); ?>">
                                                        <label for="floatingInputGrid">MEASUREMENT DATE:</label>
                                                    </div>
                                                </div>
                                                <div class="col-md mx-4">
                                                   
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->nota1 == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota1" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota1">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">1 = Ninguna </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->nota2 == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota2" checked >
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota2">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">2 = Extraviado</label>
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->nota3 == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota3" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota3">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">3 = Supera la dosis permitida</label>
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->nota4 == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota4" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota4">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">4 = Dosímetro reprocesado</label>
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->nota5 == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota5" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="nota5">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">5 = Control no utilizado en la evaluación</label> 
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->DNL == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="dnl"  checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="dnl">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">DNL = Dosímetro No Legible</label> 
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->EU == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="eu" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="eu">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1"> EU = Dosímetro en Uso </label> 
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->DPL == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="dpl" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="dpl">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">DPL = Dosímetro en Proceso de Lectura</label> 
                                                    </div>
                                                    <div class="form-check">
                                                        <?php if($dosicontasig->DSU == 'TRUE'): ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="dsu" checked>
                                                        <?php else: ?>
                                                            <input class="form-check-input" type="checkbox" value="TRUE" id="" name="dsu">
                                                        <?php endif; ?>
                                                        <label class="form-check-label" for="reverseCheck1">DSU = Dosímetro sin usar</label> 
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                            <br>
                                            
                                            <!-- ----------------BOTON--------------- -->
                                            <div class="row g-2">
                                                <div class="col-md"></div>
                                                <div class="col-md"></div>
                                                <div class="col-md d-grid gap-2">
                                                    <input type="submit" class="btn colorQA mt-2" name="update" id="update" value="EDITAR">
                                                </div>
                                                <div class="col-md d-grid gap-2">
                                                    <a class="btn btn-danger mt-2" type="button" id="cancelar" name="cancelar" href="<?php echo e(route('asignadosicontrato.info', ['asigdosicont' => $dosicontasig->contdosisededepto_id, 'mesnumber' => $dosicontasig->mes_asignacion ])); ?>"  role="button">CANCELAR</a>
                                                </div>
                                                <div class="col-md"></div>
                                                <div class="col-md"></div>
                                            </div>
                                        </form>
                                    </div>  
                                    <br>
                                </div>
                                <div class="col"></div>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col"></div>
    </div>
    <BR></BR> 


<script
src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous">
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#infoLectura a').on('click', function (e) {
            e.preventDefault()
            $(this).tab('show')
        })
    })
</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#form_edit_save_lectura_dosim').submit(function(e){
            e.preventDefault();
            Swal.fire({
                text: "SEGURO QUE DESEA MODIFICAR LA LECTURA DE ESTE DOSIMETRO?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'SI!'
                }).then((result) => {
                if (result.isConfirmed) {
                    
                    this.submit(); 
                }
            })
           
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/dosimetria/lectura_dosimetro_control_edit.blade.php ENDPATH**/ ?>