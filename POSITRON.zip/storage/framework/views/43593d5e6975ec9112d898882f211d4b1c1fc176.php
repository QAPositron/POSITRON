

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-asignaciones-entrada')->html();
} elseif ($_instance->childHasBeenRendered('yedYA7X')) {
    $componentId = $_instance->getRenderedChildComponentId('yedYA7X');
    $componentTag = $_instance->getRenderedChildComponentTagName('yedYA7X');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yedYA7X');
} else {
    $response = \Livewire\Livewire::mount('search-asignaciones-entrada');
    $html = $response->html();
    $_instance->logRenderedChild('yedYA7X', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/dosimetria/revision_asignaciones_dosimetria_general_entrada.blade.php ENDPATH**/ ?>