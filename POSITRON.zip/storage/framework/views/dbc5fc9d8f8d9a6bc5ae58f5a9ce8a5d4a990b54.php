



<?php $__env->startSection('contenido'); ?>    
        <!-- //////////////////// CONTENIDO ///////////////// -->
        
            <div class="row">

                <div class="col"></div>
                <div class="col-8">
                    <div class="card text-dark bg-light">
                        <h2 class="text-center mt-3">CREAR SEDE</h2>

                        <form class="m-4" id="form_create_sede" name="form_create_sede" action="<?php echo e(route('sedes.save')); ?>" method="POST">
                        
                            <?php echo csrf_field(); ?>
                            <label for="">AÑADA LOS DEPARTAMENTOS DE ESPECIALIDADES QUE CONTEGA ESTA SEDE</label>
                            <br>
                            <br>
                            <div class="row g-2">
                                <div class="col-10">
                                    <label for="">ESPECIALIDADES:</label>
                                    <div class="form-floating">
                                        <select class="form-select <?php $__errorArgs = ['multiple_select_depsede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="multiple_select_depsede" name="multiple_select_depsede[]" autofocus aria-label="Floating label select example" multiple="true">
                                            <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dep->id_departamento); ?>" <?php echo e(in_array($dep->id_departamento, (array) old('multiple_select_depsede', [])) ? "selected" : ""); ?>><?php echo e($dep->nombre_departamento); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['multiple_select_depsede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>    
                                </div>
                                <div class="col-md mt-4">
                                    <div class="col-md d-flex align-items-center ">
                                        <button type="button" class="btn colorQA" data-bs-toggle="modal" data-bs-target="#nuevo_deptoModal" >
                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <div class="form-floating text-wrap">
                                        <input type="text" class="form-control"   name="empresas_id" id="empresas_id" value="<?php echo e(old('empresas_id', $empresa->nombre_empresa)); ?>" autofocus style="text-transform:uppercase;" disabled>
                                        <input type="text" class="form-control <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"   name="id_empresa" id="id_empresa" value="<?php echo e(old('id_empresa', $empresa->id_empresa)); ?>" autofocus style="text-transform:uppercase;" hidden>
                                        <label for="floatingSelectGrid">EMPRESA:</label>
                                        <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-floating text-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['nombre_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="nombre_sede" id="nombre_sede" value="<?php echo e(old('nombre_sede')); ?>" autofocus style="text-transform:uppercase;">
                                        <label for="floatingInputGrid">NOMBRE DE LA SEDE:</label>
                                        <?php $__errorArgs = ['nombre_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <div class="form-group">
                                        <label for="floatingInputGrid">DEPARTAMENTO:</label>
                                        <select class="form-control <?php $__errorArgs = ['departamento_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="departamento_sede" id="departamento_sede" value="<?php echo e(old('departamento_sede')); ?>" autofocus style="text-transform:uppercase">
                                            <option value="">--SELECCIONE--</option>
                                            <?php $__currentLoopData = $departamentoscol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depacol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($depacol->id_departamentocol); ?>" <?php if(old('departamento_sede') == $depacol->id_departamentocol): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($depacol->nombre_deptocol); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['departamento_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md" id="div_municipio">
                                    <div class="spinner_municipio text-center" id="spinner_municipio">

                                    </div>

                                    <div class="form-group" id="municipio_empresa" name="municipio_empresa">
                                        <label for="floatingInputGrid">MUNICIPIO:</label>
                                        <select class="form-control <?php $__errorArgs = ['municipio_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="municipio_sede" id="municipio_sede" value="<?php echo e(old('municipio_sede')); ?>" autofocus style="text-transform:uppercase">

                                        </select>
                                        <?php $__errorArgs = ['municipio_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="form-floating text-wrap">
                                <input type="text" name="direccion_sede" id="direccion_sede" class="form-control <?php $__errorArgs = ['direccion_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('direccion_sede')); ?>"  autofocus style="text-transform:uppercase;">
                                <label for="">DIRECCIÓN:</label>
                                <?php $__errorArgs = ['direccion_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <br>
                            
                            <div class="row">
                                <div class="col"></div>
                                <div class="col d-grid gap-2">
                                    <input class="btn colorQA" type="submit" id="boton-guardar" name="boton-guardar" value="GUARDAR">
                                </div>
                                <div class="col d-grid gap-2">
                                    <a href="<?php echo e(route('empresas.info', $empresa->id_empresa)); ?>" class="btn btn-danger " type="button" id="cancelar" name="cancelar" role="button">CANCELAR</a>
                                </div>
                                <div class="col"></div>
                            </div>

                        </form>
                    </div>
                </div>
                <div class="col"></div>    
            </div>
        
        <div class="modal fade" id="nuevo_deptoModal" tabindex="-1" aria-labelledby="nuevo_deptoModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title w-100 text-center" id="nuevo_deptoModalLabel">NUEVA ESPECIALIDAD</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form-departamento')->html();
} elseif ($_instance->childHasBeenRendered('l3E2kL0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3E2kL0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3E2kL0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3E2kL0');
} else {
    $response = \Livewire\Livewire::mount('form-departamento');
    $html = $response->html();
    $_instance->logRenderedChild('l3E2kL0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    
                </div> 
            </div>
        </div>
        <script
            src="https://code.jquery.com/jquery-3.6.0.js"
            integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
            crossorigin="anonymous">
        </script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <?php if(session('guardar')== 'ok'): ?>
            <script>
                Swal.fire(
                'GUARDADO!',
                'SE HA GUARDADO CON ÉXITO.',
                'success'
                )
            </script>
        <?php endif; ?>
        <script type="text/javascript">
            $(document).ready(() => {

                $('#multiple_select_depsede').select2({
                    placeholder:"SELECCIONE LAS ESPECIALIDADES",
                    tags: true,
                    tokenSeparators: ['/',',',',',','," "]
                });
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#departamento_sede').select2();
                $('#municipio_sede').select2();
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                var olddepto = '<?php echo e(old('departamento_sede')); ?>';
                var oldciudad = '<?php echo e(old('municipio_sede')); ?>';
                if('<?php echo e(old('municipio_sede')); ?>' == ''){
                    console.log("si esta vacio");
                    console.log('<?php echo e(old('municipio_sede')); ?>');
                }else{
                    console.log("no esta vacio");
                    console.log('<?php echo e(old('municipio_sede')); ?>');
                    <?php $__currentLoopData = $municipioscol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        if('<?php echo e($muni->id_municipiocol); ?>' == oldciudad){
                            console.log('<?php echo e($muni->nombre_municol); ?>');
                            $('#municipio_sede').append("<option value='<?php echo e($muni->id_municipiocol); ?>'>" +'--<?php echo e($muni->nombre_municol); ?>--' + "</option>");
                        }
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $municipioscol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        $('#municipio_sede').append("<option value='<?php echo e($muni->id_municipiocol); ?>'>" +'<?php echo e($muni->nombre_municol); ?>' + "</option>");
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                }
                $('#departamento_sede').on('change', function(){
                    $('#municipio_empresa').fadeOut();
                    $('#spinner_municipio').html('<div class="spinner-border text-secondary" id="spinner" role="status"></div>');
                    var departamento_id = $(this).val();

                    var padre = document.getElementById("spinner_municipio");
                    var hijo = document.getElementById("spinner");
                    /* alert(departamento_id); */
                    if($.trim(departamento_id) != ''){
                        $.get('sedesdeptomuni', {departamento_id: departamento_id}, function(municipios){
                            console.log(municipios);
                            var remove = padre.removeChild(hijo);
                            $('#municipio_empresa').fadeIn();
                            $('#municipio_sede').empty();
                            $('#municipio_sede').append("<option value=''>--SELECCIONE UNA SEDE--</option>");
                            $.each(municipios, function(index, value){
                                $('#municipio_sede').append("<option value='"+ index + "'>" + value + "</option>");
                            })
                        });
                    }
                });
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#form_create_sede').submit(function(e){
                    e.preventDefault();
                    Swal.fire({
                        text: "DESEA GUARDAR ESTA SEDE??",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'SI, SEGURO!'
                        }).then((result) => {
                        if (result.isConfirmed) {
                           
                            this.submit();
                        }
                    })
                });
                $('#form_crear_depto').submit(function(e){
                    e.preventDefault();
                    Swal.fire({
                        text: "DESEA GUARDAR ESTA ESPECIALIDAD??",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'SI, SEGURO!'
                        }).then((result) => {
                        if (result.isConfirmed) {
                           
                            this.submit();
                        }
                    })
                })
            })
        </script>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/sede/crear_sede.blade.php ENDPATH**/ ?>