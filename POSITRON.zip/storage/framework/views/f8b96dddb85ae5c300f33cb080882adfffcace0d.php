

<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-md"></div>
    <div class="col-md-15">
        <div class="card text-dark bg-light">
            <h2 class="modal-title w-100 text-center">ASIGNACIÓN DOSÍMETROS</h2>
            <h3 class="modal-title w-100 text-center" id="nueva_empresaModalLabel"><i><?php echo e($contdosisededepto->contratodosimetriasede->sede->empresa->nombre_empresa); ?> - SEDE: <?php echo e($contdosisededepto->contratodosimetriasede->sede->nombre_sede); ?></i> <br>MES <?php echo e($mesnumber); ?> ( <span id="mes<?php echo e($mesnumber); ?>"></span> ), ESPECIALIDAD: <?php echo e($contdosisededepto->departamentosede->departamento->nombre_departamento); ?> </h3>
            <form action="<?php echo e(route('asignadosicontratomn.save', ['asigdosicont'=> $contdosisededepto->id_contdosisededepto, 'mesnumber'=>$mesnumber])); ?>" method="POST"  id="form-nueva-asignacion_mn" name="form-nueva-asignacion_mn" class="form-nueva-asignacion_mn m-4">
                <?php echo csrf_field(); ?>

                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md"></div>
                    <div class="col-md-6">    
                        <div class="table table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead class="table-active">
                                    <tr class="text-center">
                                        <th colspan='7'>DOSíMETROS CONTRATADOS</th>
                                    </tr>
                                    <tr class="text-center">
                                        <th>TÓRAX</th>
                                        <th>CRISTALINO</th>
                                        <th>ANILLO</th>
                                        <th>MUÑECA</th>
                                        <th>CONTROL</th>
                                        <th>ÁREA</th>
                                        <th>CASO</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_torax); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_cristalino); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_dedo); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_muñeca); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_control); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_area); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_caso); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md"></div>
                </div>
                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="form-floating">
                            <input value="" type="date" class="form-control <?php $__errorArgs = ['primerDia_asigdosim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="primerDia_asigdosim" id="primerDia_asigdosim" onchange="fechaultimodia();">
                            <label for="floatingInputGrid">PRIMER DÍA</label>
                            <?php $__errorArgs = ['primerDia_asigdosim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="invalid-feedback">*<?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input value="" type="date" class="form-control <?php $__errorArgs = ['ultimoDia_asigdosim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ultimoDia_asigdosim" id="ultimoDia_asigdosim" >
                            <label for="floatingInputGrid">ULTIMO DÍA:</label>
                            <?php $__errorArgs = ['ultimoDia_asigdosim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="invalid-feedback">*<?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div> 
                <br>   
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control" name="fecha_envio_dosim_asignado" id="fecha_envio_dosim_asignado" >
                            <label for="floatingInputGrid">FECHA ENVIO</label>
                            
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control" name="fecha_recibido_dosim_asignado" id="fecha_recibido_dosim_asignado" >
                            <label for="floatingInputGrid">FECHA RECIBIDO</label>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control" name="fecha_devuelto_dosim_asignado" id="fecha_devuelto_dosim_asignado" >
                            <label for="floatingInputGrid">FECHA DEVUELTO</label>
                        </div>
                    </div>
                </div> 
                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" class="form-control" name="energia_asigdosim" id="energia_asigdosim" value="F" readonly>
                            <label for="floatingInputGrid">ENERGÍA:</label>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" class="form-control" name="periodorecambio_asigdosim" id="periodorecambio_asigdosim" value="<?php echo e($contdosisededepto->contratodosimetriasede->dosimetriacontrato->periodo_recambio); ?>" readonly>
                            <label for="floatingInputGrid">PERIODO RECAMBIO:</label>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="table table-responsive text-center">
                            <table  class="table table-bordered" id="tablaAsignacionDosimetrosmn">
                                <thead class="table-active text-center">
                                    <th style='width: 28.20%' >TRABAJADOR / ÁREA</th>
                                    <th style='width: 16.40%'>UBICACIÓN</th>
                                    <th style='width: 16.40%'>DOSÍMETRO</th>
                                    <th style='width: 16.40%'>HOLDER</th>
                                    <th style='width: 20.60%'>OCUPACIÓN</th>
                                </thead>
                                <tbody>
                                    <input hidden name="mesNumber1" id="mesNumber1" value="<?php echo e($mesnumber); ?>">
                                    <input type="number" name="id_departamento_asigdosim" id="id_departamento_asigdosim" hidden value="<?php echo e($contdosisededepto->id_contdosisededepto); ?>">
                                    <input type="number" name="id_contrato_asigdosim_sede" id="id_contrato_asigdosim_sede" hidden value="<?php echo e($contdosisededepto->contratodosimetriasede_id); ?>">
                                    
                                    
                                    <?php $__currentLoopData = $dosicontrolmesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosicontrolant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan='2' class='align-middle text-center'>CONTROL</td>
                                            <td class='align-middle'>
                                                <select class="form-select id_dosimetro_asigdosimControl"  name="id_dosimetro_asigdosimControl[]" id="id_dosimetro_asigdosimControl" <?php if($dosicontrolant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosicontrolant->dosimetro_uso != 'FALSE'): ?> <?php echo e($dosicontrolant->dosimetro_id); ?> <?php endif; ?>"> <?php if($dosicontrolant->dosimetro_uso != 'FALSE'): ?> <?php echo e($dosicontrolant->dosimetro->codigo_dosimeter); ?> <?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class='align-middle text-center'>N.A.</td>
                                            <td>
                                                <select class="form-select ocupacion_asigdosimControl" name="ocupacion_asigdosimControl[]" id="ocupacion_asigdosimControl" style="text-transform:uppercase" <?php if($dosicontrolant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dosicontrolant->dosimetro_uso != 'FALSE'): ?>
                                                        <?php if($dosicontrolant->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">TELETERAPIA</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">BRAQUITERAPIA</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">MEDICINA NUCLEAR</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">GAMAGRAFIA INDUSTRIAL</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">MEDIDORES FIJOS</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">INVESTIGACIÓN</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">DENSÍMETRO NUCLEAR</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">MEDIDORES MÓVILES</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">DOCENCIA</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">PERFILAJE Y REGISTRO</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">TRAZADORES</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">HEMODINAMIA</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">RAYOS X ODONTOLÓGICO</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">RADIODIAGNÓSTICO</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">FLUOROSCOPÍA</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">APLICACIONES MÉDICAS</option>
                                                            <?php elseif($dosicontrolant->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">APLICACIONES INDUSTRIALES</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($mescontdosisededepto->mes_asignacion == $mesnumber || $mescontdosisededepto->mes_asignacion <= $mesnumber): ?>
                                        <?php for($i=1; $i<=($mescontdosisededepto->dosi_control - count($dosicontrolmesant)); $i++): ?>
                                            <tr>
                                                <td colspan='2' class='align-middle text-center'>CONTROL</td>
                                                <td class='align-middle'>
                                                    <select class="form-select id_dosimetro_asigdosimControl"  name="id_dosimetro_asigdosimControl[]" id="id_dosimetro_asigdosimControl" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class='align-middle text-center'>N.A.</td>
                                                <td>
                                                    <select class="form-select ocupacion_asigdosimControl" name="ocupacion_asigdosimControl[]" id="ocupacion_asigdosimControl" autofocus style="text-transform:uppercase">
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    </select>
                                                </td>
                                                <td></td>
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                    
                                    
                                    <?php $__currentLoopData = $dosiareamesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiareant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_area_asigdosimArea[]" id="id_area_asigdosimArea_mesant" value="<?php echo e($dosiareant->areadepartamentosede_id); ?>" hidden >
                                                <select class="form-select id_area_asigdosimArea"  name="id_area_asigdosimArea[]" id="id_area_asigdosimArea<?php echo e($dosiareant->areadepartamentosede_id); ?>" disabled>
                                                    <option value="<?php echo e($dosiareant->areadepartamentosede_id); ?>"><?php echo e($dosiareant->areadepartamentosede->nombre_area); ?></option>
                                                    <?php $__currentLoopData = $areaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($area->id_areadepartamentosede != $dosiareant->areadepartamentosede_id): ?>
                                                            <option  value ="<?php echo e($area->id_areadepartamentosede); ?>"><?php echo e($area->nombre_area); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">ÁREA</td>
                                            <td>
                                                <select class="form-select id_dosimetro_asigdosimArea"  name="id_dosimetro_asigdosimArea[]" id="id_dosimetro_asigdosimArea" <?php if($dosiareant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosiareant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosiareant->dosimetro_id); ?><?php endif; ?>"><?php if($dosiareant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosiareant->dosimetro->codigo_dosimeter); ?> <?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresAmbiental; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiamblib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiamblib->id_dosimetro); ?>"><?php echo e($dosiamblib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">N.A</td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimArea[]" id="ocupacion_asigdosimArea" style="text-transform:uppercase" <?php if($dosiareant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dosiareant->dosimetro_uso != 'FALSE'): ?>
                                                        <?php if($dosiareant->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">TELETERAPIA</option>
                                                            <?php elseif($dosiareant->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">BRAQUITERAPIA</option>
                                                            <?php elseif($dosiareant->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">MEDICINA NUCLEAR</option>
                                                            <?php elseif($dosiareant->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">GAMAGRAFIA INDUSTRIAL</option>
                                                            <?php elseif($dosiareant->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">MEDIDORES FIJOS</option>
                                                            <?php elseif($dosiareant->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">INVESTIGACIÓN</option>
                                                            <?php elseif($dosiareant->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">DENSÍMETRO NUCLEAR</option>
                                                            <?php elseif($dosiareant->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">MEDIDORES MÓVILES</option>
                                                            <?php elseif($dosiareant->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">DOCENCIA</option>
                                                            <?php elseif($dosiareant->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">PERFILAJE Y REGISTRO</option>
                                                            <?php elseif($dosiareant->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">TRAZADORES</option>
                                                            <?php elseif($dosiareant->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">HEMODINAMIA</option>
                                                            <?php elseif($dosiareant->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">RAYOS X ODONTOLÓGICO</option>
                                                            <?php elseif($dosiareant->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">RADIODIAGNÓSTICO</option>
                                                            <?php elseif($dosiareant->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">FLUOROSCOPÍA</option>
                                                            <?php elseif($dosiareant->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">APLICACIONES MÉDICAS</option>
                                                            <?php elseif($dosiareant->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">APLICACIONES INDUSTRIALES</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($mescontdosisededepto->mes_asignacion == $mesnumber || $mescontdosisededepto->mes_asignacion <= $mesnumber): ?>
                                        <?php for($i=1; $i<=($mescontdosisededepto->dosi_area - count($dosiareamesant)); $i++): ?>
                                            <tr>
                                                <td>
                                                    <select class="form-select id_area_asigdosimArea"  name="id_area_asigdosimArea[]" id="id_area_asigdosimArea" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $areaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option  value ="<?php echo e($area->id_areadepartamentosede); ?>"><?php echo e($area->nombre_area); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">ÁREA</td>
                                                <td>
                                                    <select class="form-select id_dosimetro_asigdosimArea"  name="id_dosimetro_asigdosimArea[]" id="id_dosimetro_asigdosimArea" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $dosimLibresAmbiental; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiamblib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($dosiamblib->id_dosimetro); ?>"><?php echo e($dosiamblib->codigo_dosimeter); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">N.A</td>
                                                <td>
                                                    <select class="form-select" name="ocupacion_asigdosimArea[]" id="ocupacion_asigdosimArea" autofocus style="text-transform:uppercase">
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    </select>
                                                </td>
                                                
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                     
                                    
                                    <?php $__currentLoopData = $dosicasomesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosicasoant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_trabajador_asigdosimCaso[]" id="id_trabajador_asigdosimCaso_mesant" value="<?php echo e($dosicasoant->persona_id); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimCaso[]" id="id_trabajador_asigdosimCaso<?php echo e($dosicasoant->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosicasoant->persona_id); ?>"> <?php if($dosicasoant->persona_id != NULL): ?> <?php echo e($dosicasoant->persona->primer_nombre_persona); ?> <?php echo e($dosicasoant->persona->segundo_nombre_persona); ?> <?php echo e($dosicasoant->persona->primer_apellido_persona); ?> <?php echo e($dosicasoant->persona->segundo_apellido_persona); ?> <?php endif; ?> </option>
                                                    
                                                    <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($persed->id_persona != $dosicasoant->persona_id): ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">CASO</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimCaso[]" id="id_dosimetro_asigdosimCaso" <?php if($dosicasoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosicasoant->dosimetro_uso != 'FALSE'): ?> <?php echo e($dosicasoant->dosimetro_id); ?> <?php endif; ?>"><?php if($dosicasoant->dosimetro_uso != 'FALSE'): ?> <?php echo e($dosicasoant->dosimetro->codigo_dosimeter); ?> <?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">N.A</td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimCaso[]" id="ocupacion_asigdosimCaso" style="text-transform:uppercase" <?php if($dosicasoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dosicasoant->dosimetro_uso != 'FALSE'): ?>
                                                        <?php if($dosicasoant->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">TELETERAPIA</option>
                                                            <?php elseif($dosicasoant->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">BRAQUITERAPIA</option>
                                                            <?php elseif($dosicasoant->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">MEDICINA NUCLEAR</option>
                                                            <?php elseif($dosicasoant->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">GAMAGRAFIA INDUSTRIAL</option>
                                                            <?php elseif($dosicasoant->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">MEDIDORES FIJOS</option>
                                                            <?php elseif($dosicasoant->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">INVESTIGACIÓN</option>
                                                            <?php elseif($dosicasoant->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">DENSÍMETRO NUCLEAR</option>
                                                            <?php elseif($dosicasoant->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">MEDIDORES MÓVILES</option>
                                                            <?php elseif($dosicasoant->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">DOCENCIA</option>
                                                            <?php elseif($dosicasoant->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">PERFILAJE Y REGISTRO</option>
                                                            <?php elseif($dosicasoant->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">TRAZADORES</option>
                                                            <?php elseif($dosicasoant->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">HEMODINAMIA</option>
                                                            <?php elseif($dosicasoant->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">RAYOS X ODONTOLÓGICO</option>
                                                            <?php elseif($dosicasoant->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">RADIODIAGNÓSTICO</option>
                                                            <?php elseif($dosicasoant->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">FLUOROSCOPÍA</option>
                                                            <?php elseif($dosicasoant->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">APLICACIONES MÉDICAS</option>
                                                            <?php elseif($dosicasoant->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">APLICACIONES INDUSTRIALES</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($mescontdosisededepto->mes_asignacion == $mesnumber || $mescontdosisededepto->mes_asignacion <= $mesnumber): ?>
                                        <?php for($i=1; $i<=($mescontdosisededepto->dosi_caso - count($dosicasomesant)); $i++): ?>
                                            <tr>
                                                <td>
                                                    <select class="form-select"  name="id_trabajador_asigdosimCaso[]" id="id_trabajador_asigdosimCaso" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        
                                                        
                                                        <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">CASO</td>
                                                <td>
                                                    <select class="form-select"  name="id_dosimetro_asigdosimCaso[]" id="id_dosimetro_asigdosimCaso" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">N.A</td>
                                                <td>
                                                    <select class="form-select" name="ocupacion_asigdosimCaso[]" id="ocupacion_asigdosimCaso" autofocus style="text-transform:uppercase">
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    </select>
                                                </td>
                                                
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                    
                                    
                                    <?php $__currentLoopData = $dositoraxmesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dositoraxant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_trabajador_asigdosimTorax[]" id="id_trabajador_asigdosimTorax_mesant" value="<?php echo e($dositoraxant->persona_id); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimTorax[]" id="id_trabajador_asigdosimTorax<?php echo e($dositoraxant->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dositoraxant->persona_id); ?>"><?php if($dositoraxant->persona_id != NULL): ?> <?php echo e($dositoraxant->persona->primer_nombre_persona); ?> <?php echo e($dositoraxant->persona->segundo_nombre_persona); ?> <?php echo e($dositoraxant->persona->primer_apellido_persona); ?> <?php echo e($dositoraxant->persona->segundo_apellido_persona); ?> <?php endif; ?></option>
                                                    
                                                    <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($persed->id_persona != $dositoraxant->persona_id): ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">TÓRAX</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimTorax[]" id="id_dosimetro_asigdosimTorax" <?php if($dositoraxant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dositoraxant->dosimetro_uso != 'FALSE'): ?> <?php echo e($dositoraxant->dosimetro_id); ?><?php endif; ?>"><?php if($dositoraxant->dosimetro_uso != 'FALSE'): ?> <?php echo e($dositoraxant->dosimetro->codigo_dosimeter); ?> <?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">N.A</td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimTorax[]" id="ocupacion_asigdosimTorax" style="text-transform:uppercase" <?php if($dositoraxant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dositoraxant->dosimetro_uso != 'FALSE'): ?>
                                                        <?php if($dositoraxant->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">TELETERAPIA</option>
                                                            <?php elseif($dositoraxant->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">BRAQUITERAPIA</option>
                                                            <?php elseif($dositoraxant->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">MEDICINA NUCLEAR</option>
                                                            <?php elseif($dositoraxant->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">GAMAGRAFIA INDUSTRIAL</option>
                                                            <?php elseif($dositoraxant->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">MEDIDORES FIJOS</option>
                                                            <?php elseif($dositoraxant->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">INVESTIGACIÓN</option>
                                                            <?php elseif($dositoraxant->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">DENSÍMETRO NUCLEAR</option>
                                                            <?php elseif($dositoraxant->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">MEDIDORES MÓVILES</option>
                                                            <?php elseif($dositoraxant->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">DOCENCIA</option>
                                                            <?php elseif($dositoraxant->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">PERFILAJE Y REGISTRO</option>
                                                            <?php elseif($dositoraxant->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">TRAZADORES</option>
                                                            <?php elseif($dositoraxant->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">HEMODINAMIA</option>
                                                            <?php elseif($dositoraxant->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">RAYOS X ODONTOLÓGICO</option>
                                                            <?php elseif($dositoraxant->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">RADIODIAGNÓSTICO</option>
                                                            <?php elseif($dositoraxant->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">FLUOROSCOPÍA</option>
                                                            <?php elseif($dositoraxant->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">APLICACIONES MÉDICAS</option>
                                                            <?php elseif($dositoraxant->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">APLICACIONES INDUSTRIALES</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($mescontdosisededepto->mes_asignacion == $mesnumber || $mescontdosisededepto->mes_asignacion <= $mesnumber): ?>
                                        <?php for($i=1; $i<=($mescontdosisededepto->dosi_torax - count($dositoraxmesant)); $i++): ?>
                                            <tr>
                                                <td>
                                                    <select class="form-select"  name="id_trabajador_asigdosimTorax[]" id="id_trabajador_asigdosimTorax" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        
                                                        <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">TÓRAX</td>
                                                <td>
                                                    <select class="form-select"  name="id_dosimetro_asigdosimTorax[]" id="id_dosimetro_asigdosimTorax" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">N.A</td>
                                                <td>
                                                    <select class="form-select" name="ocupacion_asigdosimTorax[]" id="ocupacion_asigdosimTorax" autofocus style="text-transform:uppercase">
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    </select>
                                                </td>
                                                
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                    
                                    
                                    <?php $__currentLoopData = $dosicristalinomesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosicristalinoant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_trabajador_asigdosimCristalino[]" id="id_trabajador_asigdosimCristalino_mesant" value="<?php echo e($dosicristalinoant->persona_id); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimCristalino[]" id="id_trabajador_asigdosimCristalino<?php echo e($dosicristalinoant->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosicristalinoant->persona_id); ?>"><?php if($dosicristalinoant->persona_id != NULL): ?> <?php echo e($dosicristalinoant->persona->primer_nombre_persona); ?> <?php echo e($dosicristalinoant->persona->segundo_nombre_persona); ?> <?php echo e($dosicristalinoant->persona->primer_apellido_persona); ?> <?php echo e($dosicristalinoant->persona->segundo_apellido_persona); ?> <?php endif; ?></option>
                                                    
                                                    <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($persed->id_persona != $dosicristalinoant->persona_id): ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">CRISTALINO</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimCristalino[]" id="id_dosimetro_asigdosimCristalino" <?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosicristalinoant->dosimetro_id); ?><?php endif; ?>"><?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosicristalinoant->dosimetro->codigo_dosimeter); ?> <?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select"  name="id_holder_asigdosimCristalino[]" id="id_holder_asigdosimCristalino" <?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosicristalinoant->holder_id); ?><?php endif; ?>"><?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosicristalinoant->holder->codigo_holder); ?><?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $holderLibresCristalino; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibcris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($holibcris->id_holder); ?>"><?php echo e($holibcris->codigo_holder); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimCristalino[]" id="ocupacion_asigdosimCristalino" <?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dosicristalinoant->dosimetro_uso != 'FALSE'): ?>
                                                        <?php if($dosicristalinoant->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">TELETERAPIA</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">BRAQUITERAPIA</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">MEDICINA NUCLEAR</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">GAMAGRAFIA INDUSTRIAL</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">MEDIDORES FIJOS</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">INVESTIGACIÓN</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">DENSÍMETRO NUCLEAR</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">MEDIDORES MÓVILES</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">DOCENCIA</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">PERFILAJE Y REGISTRO</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">TRAZADORES</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">HEMODINAMIA</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">RAYOS X ODONTOLÓGICO</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">RADIODIAGNÓSTICO</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">FLUOROSCOPÍA</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">APLICACIONES MÉDICAS</option>
                                                            <?php elseif($dosicristalinoant->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">APLICACIONES INDUSTRIALES</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>    
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($mescontdosisededepto->mes_asignacion == $mesnumber || $mescontdosisededepto->mes_asignacion <= $mesnumber): ?>
                                        <?php for($i=1; $i<=($mescontdosisededepto->dosi_cristalino - count($dosicristalinomesant)); $i++): ?>
                                            <tr>
                                                <td>
                                                    <select class="form-select"  name="id_trabajador_asigdosimCristalino[]" id="id_trabajador_asigdosimCristalino" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        
                                                        <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">CRISTALINO</td>
                                                <td>
                                                    <select class="form-select"  name="id_dosimetro_asigdosimCristalino[]" id="id_dosimetro_asigdosimCristalino" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select class="form-select"  name="id_holder_asigdosimCristalino[]" id="id_holder_asigdosimCristalino" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $holderLibresCristalino; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibcris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($holibcris->id_holder); ?>"><?php echo e($holibcris->codigo_holder); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select class="form-select" name="ocupacion_asigdosimCristalino[]" id="ocupacion_asigdosimCristalino" autofocus style="text-transform:uppercase">
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    </select>
                                                </td>
                                                
                                            </tr>
                                        <?php endfor; ?>
                                    
                                    <?php endif; ?>
                                    
                                    
                                    <?php $__currentLoopData = $dosimuñecamesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosimuñecant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_trabajador_asigdosimMuneca[]" id="id_trabajador_asigdosimMuneca_mesant" value="<?php echo e($dosimuñecant->persona_id); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimMuneca[]" id="id_trabajador_asigdosimMuneca<?php echo e($dosimuñecant->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosimuñecant->persona_id); ?>"><?php if($dosimuñecant->persona_id != NULL): ?> <?php echo e($dosimuñecant->persona->primer_nombre_persona); ?> <?php echo e($dosimuñecant->persona->segundo_nombre_persona); ?> <?php echo e($dosimuñecant->persona->primer_apellido_persona); ?> <?php echo e($dosimuñecant->persona->segundo_apellido_persona); ?> <?php endif; ?></option>
                                                    
                                                    <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($persed->id_persona != $dosimuñecant->persona_id): ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">MUÑECA</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimMuneca[]" id="id_dosimetro_asigdosimMuneca" <?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosimuñecant->dosimetro_id); ?><?php endif; ?>"><?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosimuñecant->dosimetro->codigo_dosimeter); ?><?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select"  name="id_holder_asigdosimMuneca[]" id="id_holder_asigdosimMuneca" <?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosimuñecant->holder_id); ?><?php endif; ?>"><?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosimuñecant->holder->codigo_holder); ?><?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $holderLibresExtrem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibexm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($holibexm->id_holder); ?>"><?php echo e($holibexm->codigo_holder); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimMuneca[]" id="ocupacion_asigdosimMuneca"  style="text-transform:uppercase" <?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dosimuñecant->dosimetro_uso != 'FALSE'): ?>
                                                        <?php if($dosimuñecant->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">TELETERAPIA</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">BRAQUITERAPIA</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">MEDICINA NUCLEAR</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">GAMAGRAFIA INDUSTRIAL</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">MEDIDORES FIJOS</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">INVESTIGACIÓN</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">DENSÍMETRO NUCLEAR</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">MEDIDORES MÓVILES</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">DOCENCIA</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">PERFILAJE Y REGISTRO</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">TRAZADORES</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">HEMODINAMIA</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">RAYOS X ODONTOLÓGICO</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">RADIODIAGNÓSTICO</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">FLUOROSCOPÍA</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">APLICACIONES MÉDICAS</option>
                                                            <?php elseif($dosimuñecant->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">APLICACIONES INDUSTRIALES</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($mescontdosisededepto->mes_asignacion == $mesnumber || $mescontdosisededepto->mes_asignacion <= $mesnumber): ?>
                                        <?php for($i=1; $i<=($mescontdosisededepto->dosi_muñeca - count($dosimuñecamesant)); $i++): ?>
                                            <tr>
                                                <td>
                                                    <select class="form-select"  name="id_trabajador_asigdosimMuneca[]" id="id_trabajador_asigdosimMuneca" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        
                                                        <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">MUÑECA</td>
                                                <td>
                                                    <select class="form-select"  name="id_dosimetro_asigdosimMuneca[]" id="id_dosimetro_asigdosimMuneca" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select class="form-select"  name="id_holder_asigdosimMuneca[]" id="id_holder_asigdosimMuneca" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $holderLibresExtrem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibexm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($holibexm->id_holder); ?>"><?php echo e($holibexm->codigo_holder); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select class="form-select" name="ocupacion_asigdosimMuneca[]" id="ocupacion_asigdosimMuneca" autofocus style="text-transform:uppercase">
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    </select>
                                                </td>
                                                
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                    
                                    
                                    <?php $__currentLoopData = $dosidedomesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosidedoant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_trabajador_asigdosimDedo[]" id="id_trabajador_asigdosimDedo_mesant" value="<?php echo e($dosidedoant->persona_id); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimDedo[]" id="id_trabajador_asigdosimDedo<?php echo e($dosidedoant->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosidedoant->persona_id); ?>"><?php if($dosidedoant->persona_id != NULL): ?> <?php echo e($dosidedoant->persona->primer_nombre_persona); ?> <?php echo e($dosidedoant->persona->segundo_nombre_persona); ?> <?php echo e($dosidedoant->persona->primer_apellido_persona); ?> <?php echo e($dosidedoant->persona->segundo_apellido_persona); ?> <?php endif; ?></option>
                                                    
                                                    <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($persed->id_persona != $dosidedoant->persona_id): ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class="align-middle text-center">ANILLO</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimDedo[]" id="id_dosimetro_asigdosimDedo"  <?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <option value="<?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosidedoant->dosimetro_id); ?><?php endif; ?>"><?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosidedoant->dosimetro->codigo_dosimeter); ?><?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select"  name="id_holder_asigdosimDedo[]" id="id_holder_asigdosimDedo" <?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?> >
                                                    <option value="<?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosidedoant->holder_id); ?><?php endif; ?>"><?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?><?php echo e($dosidedoant->holder->codigo_holder); ?><?php else: ?> ---- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $holderLibresAnillo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibanillo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($holibanillo->id_holder); ?>"><?php echo e($holibanillo->codigo_holder); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimDedo[]" id="ocupacion_asigdosipDedo" <?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dosidedoant->dosimetro_uso != 'FALSE'): ?>
                                                        <?php if($dosidedoant->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">TELETERAPIA</option>
                                                            <?php elseif($dosidedoant->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">BRAQUITERAPIA</option>
                                                            <?php elseif($dosidedoant->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">MEDICINA NUCLEAR</option>
                                                            <?php elseif($dosidedoant->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">GAMAGRAFIA INDUSTRIAL</option>
                                                            <?php elseif($dosidedoant->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">MEDIDORES FIJOS</option>
                                                            <?php elseif($dosidedoant->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">INVESTIGACIÓN</option>
                                                            <?php elseif($dosidedoant->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">DENSÍMETRO NUCLEAR</option>
                                                            <?php elseif($dosidedoant->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">MEDIDORES MÓVILES</option>
                                                            <?php elseif($dosidedoant->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">DOCENCIA</option>
                                                            <?php elseif($dosidedoant->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">PERFILAJE Y REGISTRO</option>
                                                            <?php elseif($dosidedoant->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">TRAZADORES</option>
                                                            <?php elseif($dosidedoant->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">HEMODINAMIA</option>
                                                            <?php elseif($dosidedoant->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">RAYOS X ODONTOLÓGICO</option>
                                                            <?php elseif($dosidedoant->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">RADIODIAGNÓSTICO</option>
                                                            <?php elseif($dosidedoant->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">FLUOROSCOPÍA</option>
                                                            <?php elseif($dosidedoant->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">APLICACIONES MÉDICAS</option>
                                                            <?php elseif($dosidedoant->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">APLICACIONES INDUSTRIALES</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($mescontdosisededepto->mes_asignacion == $mesnumber || $mescontdosisededepto->mes_asignacion <= $mesnumber): ?>
                                        <?php for($i=1; $i<=($mescontdosisededepto->dosi_dedo - count($dosidedomesant)); $i++): ?>
                                            <tr>
                                                <td>
                                                    <select class="form-select"  name="id_trabajador_asigdosimDedo[]" id="id_trabajador_asigdosimDedo" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        
                                                        <?php $__currentLoopData = $personaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($persed->id_persona); ?>"><?php echo e($persed->primer_nombre_persona); ?> <?php echo e($persed->segundo_nombre_persona); ?> <?php echo e($persed->primer_apellido_persona); ?> <?php echo e($persed->segundo_apellido_persona); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td class="align-middle text-center">ANILLO</td>
                                                <td>
                                                    <select class="form-select"  name="id_dosimetro_asigdosimDedo[]" id="id_dosimetro_asigdosimDedo" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select class="form-select"  name="id_holder_asigdosimDedo[]" id="id_holder_asigdosimDedo" autofocus aria-label="Floating label select example">
                                                        <option value="">----</option>
                                                        <?php $__currentLoopData = $holderLibresAnillo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibanillo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($holibanillo->id_holder); ?>"><?php echo e($holibanillo->codigo_holder); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select class="form-select" name="ocupacion_asigdosimDedo[]" id="ocupacion_asigdosipDedo" autofocus style="text-transform:uppercase">
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    </select>
                                                </td>
                                                
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <div class="d-grid gap-2 col-6 mx-auto">
                            <button id="assignBtn" class="btn colorQA"  type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-save" viewBox="0 0 16 16">
                                    <path d="M2 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H9.5a1 1 0 0 0-1 1v7.293l2.646-2.647a.5.5 0 0 1 .708.708l-3.5 3.5a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L7.5 9.293V2a2 2 0 0 1 2-2H14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h2.5a.5.5 0 0 1 0 1H2z"/>
                                </svg> <br> GUARDAR ASIGNACIÓN
                            </button>
                        </div>
                    </div>
                    <div class="col">
                        <div class="d-grip gap-2 col-6 mx-auto">
                            
                            <a href="<?php echo e(route('detallesedecont.create', $contdosisededepto->id_contdosisededepto)); ?>" class="btn btn-danger " type="button" id="cancelar" name="cancelar" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                                </svg> 
                                <br> CANCELAR ASIGNACIÓN
                            </a>
                        </div>
                    </div>
            </form>
                    <div class="col">
                        <div class="d-grid gap-2 col-6 mx-auto">
                            <a href="<?php echo e(route('asignadosicontratomn.clear',['asigdosicont' => $contdosisededepto->id_contdosisededepto, 'mesnumber' => $mesnumber] )); ?>" class="btn btn-primary limpiar_asig"  type="button" id="limpiar_asig" name="limpiar_asig" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                                    <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5ZM11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H2.506a.58.58 0 0 0-.01 0H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1h-.995a.59.59 0 0 0-.01 0H11Zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5h9.916Zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47ZM8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5Z"/>
                                </svg> <br> LIMPIAR ASIGNACIONES
                            </a>
                        </div>
                    </div>
                    <div class="col"></div>
                </div>
                
            
        </div>
        <br>
    </div>
    <div class="col md"></div>
</div>



<script
src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous">
</script>

<script type="text/javascript">
    $(document).ready(function(){
        // Creamos array con los meses del año
        const meses = ['ENERO', 'FEBRERO', 'MARZO', 'ABRIL', 'MAYO', 'JUNIO', 'JULIO', 'AGOSTO', 'SEPTIEMBRE', 'OCTUBRE', 'NOVIEMBRE', 'DICIEMBRE'];
        let fecha = new Date("<?php echo e($contdosisededepto->contratodosimetriasede->dosimetriacontrato->fecha_inicio); ?>, 00:00:00");
        
        console.log(fecha);
        for($i=0; $i<=13; $i++){
            var r = new Date(new Date(fecha).setMonth(fecha.getMonth()+$i));
            var fechaesp = meses[r.getMonth()] + ' DE ' + r.getUTCFullYear();
            console.log(r + fechaesp + "ESTA ES LA I"+($i+1)); 
            if("<?php echo e($mesnumber); ?>" == ($i+1)){
                
                document.getElementById('mes<?php echo e($mesnumber); ?>').innerHTML = fechaesp;
            } 
        }
            
    })

</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>   
<?php if(session('clear')== 'ok'): ?>
    <script>
        Swal.fire(
        'ACTUALIZADO!',
        'SE HA ACTUALIZADO CON ÉXITO.',
        'success'
        )
        
    </script>
<?php endif; ?>  


<script type="text/javascript">
   
    function fechaultimodia(){
        var fecha = document.getElementById("primerDia_asigdosim").value;
        var fecha_inicio = new Date(fecha);
        fecha_inicio.setMinutes(fecha_inicio.getMinutes() + fecha_inicio.getTimezoneOffset());
        alert(fecha_inicio);
        console.log("FECHA INICIO"+fecha_inicio);
        if('<?php echo e($contdosisededepto->contratodosimetriasede->dosimetriacontrato->periodo_recambio); ?>' == 'MENS'){
            var fecha_final_año = fecha_inicio.getFullYear();
            console.log(fecha_final_año);
            var mm = fecha_inicio.getMonth() + 2;
            var fecha_final_mes = (mm < 10 ? '0' : '')+mm;
            if(fecha_final_mes == 13){
                fecha_final_mes = '01' ;
            }
            console.log("MES "+fecha_final_mes);
            var dd = fecha_inicio.getDate();
            var fecha_final_dia = (dd < 10 ? '0' : '')+dd;
            console.log("DIA" + fecha_final_dia);
            var fecha_final = new Date(fecha_final_año+'-'+fecha_final_mes+'-'+fecha_final_dia);
            console.log("ESTA ES LA FECHA FINAL" + fecha_final);

            if(fecha_final_mes == 01){
                var fechaFinaly = fecha_final.getFullYear() + 1;
                console.log("AÑO"+fechaFinaly);
            }else{
                var fechaFinaly = fecha_final.getFullYear();
            }
            console.log(fechaFinaly);
            var fechaFinalm = fecha_final.getMonth()+1;
            var fechaFinalmm = (fechaFinalm < 10 ? '0' : '')+fechaFinalm;
            console.log(fechaFinalmm);
            var fechaFinald = fecha_final.getDate();
            var fechaFinaldd = (fechaFinald < 10 ? '0' : '')+fechaFinald;
            console.log(fechaFinaldd);
            var fechaFinalymd = fechaFinaly+'-'+fechaFinalmm+'-'+fechaFinaldd;
            console.log(fechaFinalymd);
            document.getElementById("ultimoDia_asigdosim").value = fechaFinalymd;
        }
    };
    /* function changueArea(area){
        
        Swal.fire({
            title: 'DESEA CAMBIAR DE ÁREA EN UN DOSÍMETRO TIPO "AMBIENTAL"?',
            text: "EL CAMPO A CAMBIAR SE HABILITARÁ, SELECCIONE EL ÁREA NUEVA",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1A9980',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
                <?php $__currentLoopData = $dosiareamesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    if('<?php echo e($ant->areadepartamentosede_id); ?>' == area){
                        $("#id_area_asigdosimArea<?php echo e($ant->areadepartamentosede_id); ?>").attr("disabled", false);
                        document.getElementById("id_area_asigdosimArea_mesant").remove();
                        
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        })
    }
    function changueCaso(caso){
        alert(caso);
        Swal.fire({
            title: 'DESEA CAMBIAR EL TRABAJADOR DE UN DOSÍMETRO TIPO "CASO"?',
            text: "EL CAMPO A CAMBIAR SE HABILITARÁ, SELECCIONE EL TRABAJADOR NUEVO",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1A9980',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
                <?php $__currentLoopData = $dosicasomesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casoant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    if('<?php echo e($casoant->trabajador_id); ?>' == caso){
                        $("#id_trabajador_asigdosimCaso<?php echo e($casoant->trabajador_id); ?>").attr("disabled", false);
                        document.getElementById("id_trabajador_asigdosimCaso_mesant").remove();
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        })
    }
    function changueTorax(torax){
        
        Swal.fire({
            title: 'DESEA CAMBIAR EL TRABAJADOR DE UN DOSÍMETRO TIPO "TÓRAX"?',
            text: "EL CAMPO A CAMBIAR SE HABILITARÁ, SELECCIONE EL TRABAJADOR NUEVO",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1A9980',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
                <?php $__currentLoopData = $dositoraxmesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toraxant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    if('<?php echo e($toraxant->trabajador_id); ?>' == torax){
                        $("#id_trabajador_asigdosimTorax<?php echo e($toraxant->trabajador_id); ?>").attr("disabled", false);
                        document.getElementById("id_trabajador_asigdosimTorax_mesant").remove();
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        })
    }
    function changueCristalino(cristalino){
        
        Swal.fire({
            title: 'DESEA CAMBIAR EL TRABAJADOR DE UN DOSÍMETRO TIPO "CRISTALINO"?',
            text: "EL CAMPO A CAMBIAR SE HABILITARÁ, SELECCIONE EL TRABAJADOR NUEVO",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1A9980',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
                <?php $__currentLoopData = $dosicristalinomesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cristalinoant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    if('<?php echo e($cristalinoant->trabajador_id); ?>' == cristalino){
                        $("#id_trabajador_asigdosimCristalino<?php echo e($cristalinoant->trabajador_id); ?>").attr("disabled", false);
                        document.getElementById("id_trabajador_asigdosimCristalino_mesant").remove();
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        })
    }
    function changueMuneca(muñeca){
        
        Swal.fire({
            title: 'DESEA CAMBIAR EL TRABAJADOR DE UN DOSÍMETRO TIPO "MUÑECA"?',
            text: "EL CAMPO A CAMBIAR SE HABILITARÁ, SELECCIONE EL TRABAJADOR NUEVO",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1A9980',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
                <?php $__currentLoopData = $dosimuñecamesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muñecant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    if('<?php echo e($muñecant->trabajador_id); ?>' == muñeca){
                        $("#id_trabajador_asigdosimMuneca<?php echo e($muñecant->trabajador_id); ?>").attr("disabled", false);
                        document.getElementById("id_trabajador_asigdosimMuneca_mesant").remove();
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        })
    }
    function changueDedo(dedo){
        
        Swal.fire({
            title: 'DESEA CAMBIAR EL TRABAJADOR DE UN DOSÍMETRO TIPO "ANILLO"?',
            text: "EL CAMPO A CAMBIAR SE HABILITARÁ, SELECCIONE EL TRABAJADOR NUEVO",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1A9980',
            cancelButtonColor: '#d33',
            confirmButtonText: 'SI, SEGURO!'
        }).then((result) => {
            if (result.isConfirmed) {
                <?php $__currentLoopData = $dosidedomesant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dedoant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    if('<?php echo e($dedoant->persona_id); ?>' == dedo){
                        $("#id_trabajador_asigdosimDedo<?php echo e($dedoant->persona_id); ?>").attr("disabled", false);
                        document.getElementById("id_trabajador_asigdosimDedo_mesant").remove();
                        
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        })
    } */

</script>

<script type="text/javascript">
    $(document).ready(function(){

        $('#limpiar_asig').click(function(e){
            e.preventDefault();
            Swal.fire({
                text: 'SEGURO QUE DESEA LIMPIAR LA INFORMACIÓN DE LAS ASIGNACIONES DEL MES ANTERIOR?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33    ',
                confirmButtonText: 'SI, SEGURO!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?php echo e(route('asignadosicontratomn.clear',['asigdosicont' => $contdosisededepto->id_contdosisededepto, 'mesnumber' => $mesnumber] )); ?>";
                }
            })
        })
    })
</script>

<script type="text/javascript">
    $(document).ready(function(){
        $('#form-nueva-asignacion_mn').submit(function(e){
            e.preventDefault();

            ///////////////////////VALIDACION PARA LAS FECHAS/////////////////
            var fecha_inicio = document.getElementById("primerDia_asigdosim").value;
            if(fecha_inicio == ''){
                    /* return alert("FALTA SELECCIONAR ALGUN TRABAJADOR"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR LA FECHA DEL PRIMER DÍA PARA EL PERIODO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
            };
            var fecha_final = document.getElementById("ultimoDia_asigdosim").value;
            if(fecha_final == ''){
                    /* return alert("FALTA SELECCIONAR ALGUN TRABAJADOR"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR LA FECHA DEL ULTIMO DÍA PARA EL PERIODO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
            };
            /////////////////////VALIDACION PARA LOS DOSIMETROS/////////////////
            var dosimControl = document.querySelectorAll('select[name="id_dosimetro_asigdosimControl[]"]');
            console.log("ESTAS SON LOS  DOSIM CONTROL");
            console.log(dosimControl);
            for(var i = 0; i < dosimControl.length; i++){
                var values = dosimControl[i].value;
                if(values == ''){
                    return Swal.fire({
                                title:"FALTA SELECCIONAR EL DOSÍMETRO DE TIPO CONTROL",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
                };
                for(var x = 0; x < dosimControl.length; x++){
                    var valuesX = dosimControl[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS CONTROL SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            var dosimArea = document.querySelectorAll('select[name="id_dosimetro_asigdosimArea[]"]');
            console.log("ESTAS SON LOS DOSIMTROS AREA");
            console.log(dosimArea);
            for(var i = 0; i < dosimArea.length; i++){
                var values = dosimArea[i].value;
                if(values == ''){
                    return Swal.fire({
                                title:"FALTA SELECCIONAR EL DOSÍMETRO PARA UNO DE UBICACIÓN ÁREA",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
                };
                for(var x = 0; x < dosimArea.length; x++){
                    var valuesX = dosimArea[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS DE UBICACIÓN ÁREA SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            var dosimCaso = document.querySelectorAll('select[name="id_dosimetro_asigdosimCaso[]"]');
            console.log("ESTAS SON LOS DOSIMETROS CASO");
            console.log(dosimCaso);
            for(var i = 0; i < dosimCaso.length; i++){
                var values = dosimCaso[i].value;
                if(values == ''){
                    
                    return Swal.fire({
                                title:"FALTA SELECCIONAR EL DOSÍMETRO PARA UNO DE UBICACIÓN CASO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                };
                for(var x = 0; x < dosimCaso.length; x++){
                    var valuesX = dosimCaso[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS DE UBICACIÓN CASO SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            var dosimTorax = document.querySelectorAll('select[name="id_dosimetro_asigdosimTorax[]"]');
            console.log("ESTAS SON LOS DOSIMETROS TORAX");
            console.log(dosimTorax);
            for(var i = 0; i < dosimTorax.length; i++){
                var values = dosimTorax[i].value;
                if(values == ''){
                    return Swal.fire({
                                title:"FALTA SELECCIONAR EL DOSÍMETRO PARA UNO DE UBICACIÓN TÓRAX",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
                };
                for(var x = 0; x < dosimTorax.length; x++){
                    var valuesX = dosimTorax[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS DE UBICACIÓN TÓRAX SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            var dosimCristalino = document.querySelectorAll('select[name="id_dosimetro_asigdosimCristalino[]"]');
            console.log("ESTAS SON LOS DOSIMETROS CRISTALINO");
            console.log(dosimCristalino);
            for(var i = 0; i < dosimCristalino.length; i++){
                var values = dosimCristalino[i].value;
                if(values == ''){
                    return Swal.fire({
                                title:"FALTA SELECCIONAR EL DOSÍMETRO PARA UNO DE UBICACIÓN CRISTALINO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
                };
                for(var x = 0; x < dosimCristalino.length; x++){
                    var valuesX = dosimCristalino[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS DE UBICACIÓN CRISTALINO SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            var dosimMuneca = document.querySelectorAll('select[name="id_dosimetro_asigdosimMuneca[]"]');
            console.log("ESTAS SON LOS DOSIMETROS MUÑECA");
            console.log(dosimMuneca);
            for(var i = 0; i < dosimMuneca.length; i++){
                var values = dosimMuneca[i].value;
                if(values == ''){
                    return Swal.fire({
                                title:"FALTA SELECCIONAR EL DOSÍMETRO PARA UNO DE UBICACIÓN MUÑECA",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
                };
                for(var x = 0; x < dosimMuneca.length; x++){
                    var valuesX = dosimMuneca[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS DE UBICACIÓN MUÑECA SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };

            var dosimAnillo = document.querySelectorAll('select[name="id_dosimetro_asigdosimDedo[]"]');
            console.log("ESTAS SON LOS DOSIMETROS ANILLO");
            console.log(dosimAnillo);
            for(var i = 0; i < dosimAnillo.length; i++){
                var values = dosimAnillo[i].value;
                console.log("VALOR DE LOS DOSIMETROS ANILLO" +values)
                if(values == ''){
                    return Swal.fire({
                                title:"FALTA SELECCIONAR EL DOSÍMETRO PARA UNO DE UBICACIÓN ANILLO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                    
                };
                for(var x = 0; x < dosimAnillo.length; x++){
                    var valuesX = dosimAnillo[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS DE UBICACIÓN ANILLO SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            /////////////////////VALIDACION PARA DOSIMETROS REPETIDOS ENTRE CONTROL y TORAX /////////////////
            var dosimContr = document.querySelectorAll('select[name="id_dosimetro_asigdosimControl[]"]');
            console.log("DOSIMETROS DE TIPO CONTROL");
            console.log(dosimContr);
            for(var i = 0; i < dosimContr.length; i++){
                console.log("DOSIMETRO CONTROL POSICION" +i);
                var valuesContr = dosimContr[i].value;
                console.log(valuesContr);
                var dosimTorax = document.querySelectorAll('select[name="id_dosimetro_asigdosimTorax[]"]');
                console.log("DOSIMETROS DE TIPO TORAX");
                console.log(dosimTorax);
                for(var x = 0; x < dosimTorax.length; x++){
                    console.log("DOSIMETRO TORAX POSICION" +x);
                    var valuesTorax = dosimTorax[x].value;
                    console.log(valuesTorax);
                    if(valuesContr == valuesTorax){

                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS CUERPO ENTERO SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            }); 
                    }
                }
            };
            /////////////////////VALIDACION PARA DOSIMETROS REPETIDOS ENTRE CRISTALINO y (ANILLO, MUÑECA) /////////////////
            
            var dosimCrist = document.querySelectorAll('select[name="id_dosimetro_asigdosimCristalino[]"]');
            console.log("DOSIMETROS DE TIPO CRISTALINO");
            console.log(dosimCrist);
            for(var i = 0; i < dosimCrist.length; i++){
                console.log("DOSIMETRO CRISTALINO POSICION" +i);
                var valuesCrist = dosimCrist[i].value;
                console.log(valuesCrist);
                var dosimMun = document.querySelectorAll('select[name="id_dosimetro_asigdosimMuneca[]"]');
                console.log("DOSIMETROS DE TIPO MUÑECA");
                console.log(dosimMun);
                for(var x = 0; x < dosimMun.length; x++){
                    console.log("DOSIMETRO MUÑECA POSICION" +x);
                    var valuesMun = dosimMun[x].value;
                    console.log(valuesMun);
                    if(valuesCrist == valuesMun){

                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS EZCLIP SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            }); 
                    }
                }
            };
            for(var i = 0; i < dosimCrist.length; i++){
                console.log("DOSIMETRO CRISTALINO POSICION" +i);
                var valuesCrist = dosimCrist[i].value;
                console.log(valuesCrist);
                var dosimAni = document.querySelectorAll('select[name="id_dosimetro_asigdosimDedo[]"]');
                console.log("DOSIMETROS DE TIPO ANILLO");
                console.log(dosimAni);
                console.log("TAMAÑO DOSIMETRO ANILLO" +dosimAni.length)
                for(var x = 0; x < dosimAni.length; x++){
                    console.log("DOSIMETRO ANILLO POSICION" +x);
                    var valuesAni = dosimAni[x].value;
                    console.log(valuesAni);
                    if(valuesCrist == valuesAni){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS EZCLIP SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            /////////////////////VALIDACION PARA DOSIMETROS REPETIDOS ENTRE MUÑECA y (ANILLO, CRISTALINO) /////////////////
            var dosimMun = document.querySelectorAll('select[name="id_dosimetro_asigdosimMuneca[]"]');
            console.log("DOSIMETROS DE TIPO MUÑECA");
            console.log(dosimMun);
            for(var i = 0; i < dosimMun.length; i++){
                console.log("DOSIMETRO MUÑECA POSICION" +i);
                var valuesMun = dosimMun[i].value;
                console.log(valuesMun);
                var dosimAni = document.querySelectorAll('select[name="id_dosimetro_asigdosimDedo[]"]');
                console.log("DOSIMETROS DE TIPO ANILLO");
                console.log(dosimAni);
                for(var x = 0; x < dosimAni.length; x++){
                    console.log("DOSIMETRO ANILLO POSICION" +x);
                    var valuesAni = dosimAni[x].value;
                    console.log(valuesAni);
                    if(valuesMun == valuesAni){

                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS EZCLIP SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            }); 
                    }
                }
            };
            for(var i = 0; i < dosimMun.length; i++){
                console.log("DOSIMETRO MUÑECA POSICION" +i);
                var valuesMun = dosimMun[i].value;
                console.log(valuesMun);
                var dosimCris = document.querySelectorAll('select[name="id_dosimetro_asigdosimCristalino[]"]');
                console.log("DOSIMETROS DE TIPO CRISTALINO");
                console.log(dosimCris);
                console.log("TAMAÑO DOSIMETRO CRISTALINO" +dosimCris.length)
                for(var x = 0; x < dosimCris.length; x++){
                    console.log("DOSIMETRO CRISTALINO POSICION" +x);
                    var valuesCris = dosimCris[x].value;
                    console.log(valuesCris);
                    if(valuesMun == valuesCris){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS EZCLIP SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            /////////////////////VALIDACION PARA DOSIMETROS REPETIDOS ENTRE ANILLO y (MUÑECA, CRISTALINO) /////////////////
            var dosimAni = document.querySelectorAll('select[name="id_dosimetro_asigdosimDedo[]"]');
            console.log("DOSIMETROS DE TIPO ANILLO");
            console.log(dosimAni);
            for(var i = 0; i < dosimAni.length; i++){
                console.log("DOSIMETRO ANILLO POSICION" +i);
                var valuesAni = dosimAni[i].value;
                console.log(valuesAni);
                var dosimMun = document.querySelectorAll('select[name="id_dosimetro_asigdosimMuneca[]"]');
                console.log("DOSIMETROS DE TIPO MUÑECA");
                console.log(dosimMun);
                for(var x = 0; x < dosimMun.length; x++){
                    console.log("DOSIMETRO MUÑECA POSICION" +x);
                    var valuesMun = dosimMun[x].value;
                    console.log(valuesMun);
                    if(valuesAni == valuesMun){

                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS EZCLIP SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            }); 
                    }
                }
            };
            for(var i = 0; i < dosimAni.length; i++){
                console.log("DOSIMETRO ANILLO POSICION" +i);
                var valuesAni = dosimAni[i].value;
                console.log(valuesAni);
                var dosimCris = document.querySelectorAll('select[name="id_dosimetro_asigdosimCristalino[]"]');
                console.log("DOSIMETROS DE TIPO CRISTALINO");
                console.log(dosimCris);
                console.log("TAMAÑO DOSIMETRO CRISTALINO" +dosimCris.length);
                for(var x = 0; x < dosimCris.length; x++){
                    console.log("DOSIMETRO CRISTALINO POSICION" +x);
                    var valuesCris = dosimCris[x].value;
                    console.log(valuesCris);

                    if(valuesAni == valuesCris){
                        return Swal.fire({
                                title:"ALGUNOS DOSÍMETROS EZCLIP SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            /////////////////////VALIDACION PARA LOS HOLDERS /////////////////
            var holCristalino = document.querySelectorAll('select[name="id_holder_asigdosimCristalino[]"]');
            console.log("ESTAS SON LOS HOLDERS DE CRISTALINO");
            console.log(holCristalino);
            for(var i = 0; i < holCristalino.length; i++) {
                var values = holCristalino[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGÚN HOLDER PARA UN DOSIMETRO DE UBICACIÓN CRISTALINO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                };
                for(var x = 0; x < holCristalino.length; x++){
                    var valuesX = holCristalino[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS HOLDERS DE UBICACIÓN CRISTALINO SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            }; 
            var holAnillo = document.querySelectorAll('select[name="id_holder_asigdosimDedo[]"]');
            console.log("ESTAS SON LOS HOLDERS DE ANILLO");
            console.log(holAnillo);
            for(var i = 0; i < holAnillo.length; i++) {
                var values = holAnillo[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGÚN HOLDER PARA UN DOSÍMETRO DE UBICACIÓN ANILLO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                };
                for(var x = 0; x < holAnillo.length; x++){
                    var valuesX = holAnillo[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS HOLDERS DE UBICACIÓN ANILLO SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };
            var holMuneca = document.querySelectorAll('select[name="id_holder_asigdosimMuneca[]"]');
            console.log("ESTAS SON LOS HOLDERS DE ANILLO");
            console.log(holMuneca);
            for(var i = 0; i < holMuneca.length; i++) {
                var values = holMuneca[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGÚN HOLDER PARA UN DOSÍMETRO DE UBICACIÓN MUÑECA",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                };
                for(var x = 0; x < holMuneca.length; x++){
                    var valuesX = holMuneca[x].value;
                    if(values == valuesX && i != x){
                        return Swal.fire({
                                title:"ALGUNOS HOLDERS DE UBICACIÓN MUÑECA SELECCIONADOS SE ENCUENTRAN REPETIDOS",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN CORRECTAMENTE",
                                icon: 'error'
                            });
                    }
                }
            };  
            /////////////////////VALIDACION PARA LAS OCUPACIONES /////////////////
            var ocuControl = document.querySelectorAll('select[name="ocupacion_asigdosimControl[]"]');
            console.log("ESTAS SON LAS OCUPACIONES DE CONTROL");
            console.log(ocuControl);  
            for(var i = 0; i < ocuControl.length; i++) {
                var values = ocuControl[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR LA OCUPACIÓN DEL DOSIMETRO CONTROL",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                }
            };
            var ocuArea = document.querySelectorAll('select[name="ocupacion_asigdosimArea[]"]');
            console.log("ESTAS SON LAS OCUPACIONES DE AREA");
            console.log(ocuArea);  
            for(var i = 0; i < ocuArea.length; i++) {
                var values = ocuArea[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGUNA OCUPACIÓN DE UN DOSÍMETRO CON UBICACIÓN ÁREA",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                }
            };
            var ocuCaso = document.querySelectorAll('select[name="ocupacion_asigdosimCaso[]"]');
            console.log("ESTAS SON LAS OCUPACIONES DE CASO");
            console.log(ocuCaso);  
            for(var i = 0; i < ocuCaso.length; i++) {
                var values = ocuCaso[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGUNA OCUPACIÓN DE UN DOSÍMETRO CON UBICACIÓN CASO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                }
            };
            var ocuTorax = document.querySelectorAll('select[name="ocupacion_asigdosimTorax[]"]');
            console.log("ESTAS SON LAS OCUPACIONES DE TORAX");
            console.log(ocuTorax);  
            for(var i = 0; i < ocuTorax.length; i++) {
                var values = ocuTorax[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGUNA OCUPACIÓN DE UN DOSÍMETRO CON UBICACIÓN TÓRAX",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                }
            };
            var ocuCristalino = document.querySelectorAll('select[name="ocupacion_asigdosimCristalino[]"]');
            console.log("ESTAS SON LAS OCUPACIONES DE CRISTALINO");
            console.log(ocuCristalino);  
            for(var i = 0; i < ocuCristalino.length; i++) {
                var values = ocuCristalino[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGUNA OCUPACIÓN DE UN DOSÍMETRO CON UBICACIÓN CRISTALINO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                }
            };
            var ocuMuneca = document.querySelectorAll('select[name="ocupacion_asigdosimMuneca[]"]');
            console.log("ESTAS SON LAS OCUPACIONES DE MUÑECA");
            console.log(ocuMuneca);  
            for(var i = 0; i < ocuMuneca.length; i++) {
                var values = ocuMuneca[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGUNA OCUPACIÓN DE UN DOSÍMETRO CON UBICACIÓN MUÑECA",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                }
            };
            var ocuAnillo = document.querySelectorAll('select[name="ocupacion_asigdosimDedo[]"]');
            console.log("ESTAS SON LAS OCUPACIONES DE ANILLO");
            console.log(ocuAnillo);  
            for(var i = 0; i < ocuAnillo.length; i++) {
                var values = ocuAnillo[i].value;
                if(values == ''){
                    /* alert("FALTA SELECCIONAR ALGUN HOLDER"); */
                    return Swal.fire({
                                title:"FALTA SELECCIONAR ALGUNA OCUPACIÓN DE UN DOSÍMETRO CON UBICACIÓN ANILLO",
                                text: "VERIFIQUE LAS CASILLAS Y SELECCIONE LA INFORMACIÓN DESEADA",
                                icon: 'error'
                            });
                }
            };

            Swal.fire({
                text: "DESEA GUARDAR ESTA ASIGNACIÓN??",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'SI, SEGURO!'
                }).then((result) => {
                if (result.isConfirmed) {
                   
                    this.submit();
                }
            })
        })
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/dosimetria/asignar_dosimetro_contrato_mn.blade.php ENDPATH**/ ?>