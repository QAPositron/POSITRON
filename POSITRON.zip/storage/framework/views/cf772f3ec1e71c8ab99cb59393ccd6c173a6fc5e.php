
    <?php $__env->startSection('content'); ?>
    <!-- ///////////////HEADER NAV/////////// -->
    <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- //////////////////// CONTENIDO ///////////////// -->
    <div class="container mt-5 p-auto ">
        <?php echo $__env->yieldContent('contenido'); ?>
    </div>
    <?php $__env->stopSection(); ?>

    
 
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/layouts/plantillabase.blade.php ENDPATH**/ ?>