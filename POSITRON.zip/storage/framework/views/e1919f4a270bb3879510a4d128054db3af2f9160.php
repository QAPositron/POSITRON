<header>
  <nav class="navbar  navbar-expand-md navbar-dark colorQA">
    <div class="container">
      
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">INICIO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('empresas.*') ? 'active' : ''); ?>"  href="<?php echo e(route('empresas.search')); ?>">ADMINISTRACIÓN</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle <?php echo e(request()->routeIs('holders.*') || request()->routeIs('dosimetros.*') || request()->routeIs('empresasdosi.*') || request()->routeIs('contratosdosi.*') || request()->routeIs('contratosdosisede.*') || request()->routeIs('contratosdosisededepto.*') || request()->routeIs('detallesedecont.*') || request()->routeIs('detallecontrato.*') || request()->routeIs('asignadosicontratom1.*') || request()->routeIs('asignadosicontratomn.*') || request()->routeIs('asignadosicontrato.*') || request()->routeIs('asigdosicont.*') || request()->routeIs('lecturadosi.*') || request()->routeIs('lecturadosicontrl.*') || request()->routeIs('lecturadosicontrol.*') || request()->routeIs('lecturadosiarea.*') ? 'active' : ''); ?>" 
            href="" role="button" data-bs-toggle="dropdown" aria-expanded="false">DOSIMETRÍA</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="<?php echo e(route('empresasdosi.create')); ?>">EMPRESAS</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('dosimetros.search')); ?>">INVENTARIO</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('revisiondosimetria.create')); ?>">REVISIÓN DE SALIDA</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('revisiondosimetriaentrada.create')); ?>">REVISIÓN DE ENTRADA</a></li>
              
              <li><a class="dropdown-item" href="<?php echo e(route('novedadesdosimetria.search')); ?>">NOVEDADES NUEVO</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('personas.*') ? 'active' : ''); ?>" href="<?php echo e(route('personas.search')); ?>">PERSONAS</a>
          </li>
          
        </ul>
        <span class="navbar-text">
          MODULO DOSIMETRÍA
        </span>
      </div>
    </div>
  </nav>
</header><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>