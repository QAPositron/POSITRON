
<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-md"></div>
    <div class="col-md-15">
        <div class="card text-dark bg-light">
            <h2 class="modal-title w-100 text-center">ASIGNACIÓN DE DOSÍMETROS DESPUÉS DE NOVEDAD</h2>
            <h3 class="modal-title w-100 text-center" id="nueva_empresaModalLabel"><i><?php echo e($contdosisededepto->contratodosimetriasede->sede->empresa->nombre_empresa); ?> - SEDE: <?php echo e($contdosisededepto->contratodosimetriasede->sede->nombre_sede); ?></i> <br>MES <?php echo e($mesnumber); ?> ( <span id="mes<?php echo e($mesnumber); ?>"></span> ), ESPECIALIDAD: <?php echo e($contdosisededepto->departamentosede->departamento->nombre_departamento); ?> </h3>
            <form action="<?php echo e(route('asignadosicontratomnNovedad.save', ['asigdosicont'=> $contdosisededepto->id_contdosisededepto, 'mesnumber'=>$mesnumber])); ?>" method="POST"  id="form-nueva-asignacion_mn" name="form-nueva-asignacion_mn" class="form-nueva-asignacion_mn m-4">
                <?php echo csrf_field(); ?>
                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md"></div>
                    <div class="col-md-6">    
                        <div class="table table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead class="table-active">
                                    <tr class="text-center">
                                        <th colspan='7'>DOSíMETROS CONTRATADOS</th>
                                    </tr>
                                    <tr class="text-center">
                                        <th>TÓRAX</th>
                                        <th>CRISTALINO</th>
                                        <th>ANILLO</th>
                                        <th>MUÑECA</th>
                                        <th>CONTROL</th>
                                        <th>ÁREA</th>
                                        <th>CASO</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_torax); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_cristalino); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_dedo); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_muñeca); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_control); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_area); ?></td>
                                        <td class="text-center"><?php echo e($mescontdosisededepto->dosi_caso); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md"></div>
                </div>
                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control" name="primerDia_asigdosim" id="primerDia_asigdosim" <?php $__currentLoopData = $asignacionesMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asigMes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($asigMes->primer_dia_uso); ?>" <?php break; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            <label for="floatingInputGrid">PRIMER DÍA</label>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control " name="ultimoDia_asigdosim" id="ultimoDia_asigdosim" <?php $__currentLoopData = $asignacionesMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asigMes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($asigMes->ultimo_dia_uso); ?>" <?php break; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            <label for="floatingInputGrid">ULTIMO DÍA:</label>
                        </div>
                    </div>
                </div> 
                <br>   
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control" name="fecha_envio_dosim_asignado" id="fecha_envio_dosim_asignado" <?php $__currentLoopData = $asignacionesMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asigMes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($asigMes->fecha_dosim_enviado); ?>" <?php break; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            <label for="floatingInputGrid">FECHA ENVIO</label>
                            
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control" name="fecha_recibido_dosim_asignado" id="fecha_recibido_dosim_asignado" <?php $__currentLoopData = $asignacionesMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asigMes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($asigMes->fecha_dosim_recibido); ?>" <?php break; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            <label for="floatingInputGrid">FECHA RECIBIDO</label>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" class="form-control" name="fecha_devuelto_dosim_asignado" id="fecha_devuelto_dosim_asignado" <?php $__currentLoopData = $asignacionesMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asigMes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($asigMes->fecha_dosim_devuelto); ?>" <?php break; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            <label for="floatingInputGrid">FECHA DEVUELTO</label>
                        </div>
                    </div>
                </div> 
                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" class="form-control" name="energia_asigdosim" id="energia_asigdosim" value="F" readonly>
                            <label for="floatingInputGrid">ENERGÍA:</label>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" class="form-control" name="periodorecambio_asigdosim" id="periodorecambio_asigdosim" value="<?php echo e($contdosisededepto->contratodosimetriasede->dosimetriacontrato->periodo_recambio); ?>" readonly>
                            <label for="floatingInputGrid">PERIODO RECAMBIO:</label>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2 mx-3">
                    <div class="col-md">
                        <div class="table table-responsive text-center">
                            <table  class="table table-bordered" id="tablaAsignacionDosimetrosmn">
                                <thead class="table-active text-center">
                                    <th style='width: 28.20%' >TRABAJADOR / ÁREA</th>
                                    <th style='width: 16.40%'>UBICACIÓN</th>
                                    <th style='width: 16.40%'>DOSÍMETRO</th>
                                    <th style='width: 16.40%'>HOLDER</th>
                                    <th style='width: 20.60%'>OCUPACIÓN</th>
                                </thead>
                                <tbody>
                                    <input hidden name="mesNumber" id="mesNumber" value="<?php echo e($mesnumber); ?>">
                                    <input type="number" name="id_departamento_asigdosim" id="id_departamento_asigdosim" hidden value="<?php echo e($contdosisededepto->id_contdosisededepto); ?>">
                                    <input type="number" name="id_contrato_asigdosim_sede" id="id_contrato_asigdosim_sede" hidden value="<?php echo e($contdosisededepto->contratodosimetriasede_id); ?>">
                                    

                                    <?php $__currentLoopData = $dosicontrolmesact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosicontrolact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <input type="number" name="id_dosicontrolAsig[]" id="id_dosicontrolAsig" value="<?php echo e($dosicontrolact->id_dosicontrolcontdosisedes); ?>" hidden >
                                            <td colspan='2' class='align-middle'>CONTROL</td>
                                            <td class='align-middle'>
                                                <select class="form-select id_dosimetro_asigdosimControl"  name="id_dosimetro_asigdosimControl[]" id="id_dosimetro_asigdosimControl" >
                                                    <option value="<?php if($dosicontrolact->dosimetro_id != NULL): ?><?php echo e($dosicontrolact->dosimetro_id); ?><?php endif; ?>"><?php if($dosicontrolact->dosimetro_id == NULL): ?> -- <?php else: ?> --<?php echo e($dosicontrolact->dosimetro->codigo_dosimeter); ?>-- <?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td class='align-middle'>N.A.</td>
                                            <td>
                                                <select class="form-select ocupacion_asigdosimControl" name="ocupacion_asigdosimControl[]" id="ocupacion_asigdosimControl" style="text-transform:uppercase" >
                                                    
                                                    <?php if($dosicontrolact->ocupacion != NULL): ?>    
                                                        <?php if($dosicontrolact->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">--TELETERAPIA--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">--BRAQUITERAPIA--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">--MEDICINA NUCLEAR--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">--GAMAGRAFIA INDUSTRIAL--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">--MEDIDORES FIJOS--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">--INVESTIGACIÓN--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">--DENSÍMETRO NUCLEAR--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">--MEDIDORES MÓVILES--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">--DOCENCIA--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">--PERFILAJE Y REGISTRO--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">--TRAZADORES--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">--HEMODINAMIA--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">--RAYOS X ODONTOLÓGICO--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">--RADIODIAGNÓSTICO--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">--FLUOROSCOPÍA--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">--APLICACIONES MÉDICAS--</option>
                                                            <?php elseif($dosicontrolact->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">--APLICACIONES INDUSTRIALES--</option>
                                                        <?php endif; ?>
                                                    <?php else: ?>  
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    <?php endif; ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php $__currentLoopData = $dosiareamesact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiareact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_dosiareaAsig[]" id="id_dosiareaAsig" value="<?php echo e($dosiareact->id_dosiareacontdosisedes); ?>" hidden >
                                                <select class="form-select id_area_asigdosimArea"  name="id_area_asigdosimArea[]" id="id_area_asigdosimArea<?php echo e($dosiareact->areadepartamentosede_id); ?>" disabled>
                                                    <option value="<?php echo e($dosiareact->areadepartamentosede_id); ?>">--<?php echo e($dosiareact->areadepartamentosede->nombre_area); ?>--</option>
                                                    <?php $__currentLoopData = $areaSede; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($area->id_areadepartamentosede != $dosiareact->areadepartamentosede_id): ?>
                                                            <option  value ="<?php echo e($area->id_areadepartamentosede); ?>"><?php echo e($area->nombre_area); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>ÁREA</td>
                                            <td>
                                                <select class="form-select id_dosimetro_asigdosimArea"  name="id_dosimetro_asigdosimArea[]" id="id_dosimetro_asigdosimArea">
                                                    <option value="<?php if($dosiareact->dosimetro_id != NULL): ?><?php echo e($dosiareact->dosimetro_id); ?><?php endif; ?>"><?php if($dosiareact->dosimetro_id == NULL): ?>-- <?php else: ?>--<?php echo e($dosiareact->dosimetro->codigo_dosimeter); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresAmbiental; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiamblib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiamblib->id_dosimetro); ?>"><?php echo e($dosiamblib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>N.A</td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimArea[]" id="ocupacion_asigdosimArea" style="text-transform:uppercase" <?php if($dosiareant->dosimetro_uso != 'FALSE'): ?> { disabled } <?php endif; ?>>
                                                    <?php if($dosiareact->ocupacion != NULL): ?>    
                                                        <?php if($dosiareact->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">--TELETERAPIA--</option>
                                                            <?php elseif($dosiareact->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">--BRAQUITERAPIA--</option>
                                                            <?php elseif($dosiareact->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">--MEDICINA NUCLEAR--</option>
                                                            <?php elseif($dosiareact->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">--GAMAGRAFIA INDUSTRIAL--</option>
                                                            <?php elseif($dosiareact->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">--MEDIDORES FIJOS--</option>
                                                            <?php elseif($dosiareact->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">--INVESTIGACIÓN--</option>
                                                            <?php elseif($dosiareact->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">--DENSÍMETRO NUCLEAR--</option>
                                                            <?php elseif($dosiareact->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM"-->MEDIDORES MÓVILES--</option>
                                                            <?php elseif($dosiareact->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">--DOCENCIA--</option>
                                                            <?php elseif($dosiareact->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">--PERFILAJE Y REGISTRO--</option>
                                                            <?php elseif($dosiareact->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">--TRAZADORES--</option>
                                                            <?php elseif($dosiareact->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">--HEMODINAMIA--</option>
                                                            <?php elseif($dosiareact->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">--RAYOS X ODONTOLÓGICO--</option>
                                                            <?php elseif($dosiareact->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">--RADIODIAGNÓSTICO--</option>
                                                            <?php elseif($dosiareact->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">--FLUOROSCOPÍA--</option>
                                                            <?php elseif($dosiareact->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">--APLICACIONES MÉDICAS--</option>
                                                            <?php elseif($dosiareact->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">--APLICACIONES INDUSTRIALES--</option>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    <?php endif; ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php $__currentLoopData = $dosicasomesact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosicasoact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_asigdosimCaso[]" id="id_asigdosimCaso" value="<?php echo e($dosicasoact->id_trabajadordosimetro); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimCaso[]" id="id_trabajador_asigdosimCaso<?php echo e($dosicasoact->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosicasoact->persona_id); ?>"> <?php echo e($dosicasoant->persona->primer_nombre_persona); ?> <?php echo e($dosicasoant->persona->segundo_nombre_persona); ?> <?php echo e($dosicasoant->persona->primer_apellido_persona); ?> <?php echo e($dosicasoant->persona->segundo_apellido_persona); ?></option>
                                                    
                                                </select>
                                            </td>
                                            <td>CASO</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimCaso[]" id="id_dosimetro_asigdosimCaso">
                                                    <option value="<?php if($dosicasoact->dosimetro_id != NULL): ?><?php echo e($dosicasoact->dosimetro_id); ?> <?php endif; ?>"><?php if($dosicasoact->dosimetro_id == NULL): ?> -- <?php else: ?>--<?php echo e($dosicasoact->dosimetro->codigo_dosimeter); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>N.A</td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimCaso[]" id="ocupacion_asigdosimCaso" style="text-transform:uppercase" >
                                                    <?php if($dosicasoact->ocupacion != NULL): ?>    
                                                        <?php if($dosicasoact->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">--TELETERAPIA--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">--BRAQUITERAPIA--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">--MEDICINA NUCLEAR--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">--GAMAGRAFIA INDUSTRIAL--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">--MEDIDORES FIJOS--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">--INVESTIGACIÓN--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">--DENSÍMETRO NUCLEAR--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">--MEDIDORES MÓVILES--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">--DOCENCIA--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">--PERFILAJE Y REGISTRO--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">--TRAZADORES--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">--HEMODINAMIA--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">--RAYOS X ODONTOLÓGICO--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">--RADIODIAGNÓSTICO--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">--FLUOROSCOPÍA--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">--APLICACIONES MÉDICAS--</option>
                                                            <?php elseif($dosicasoact->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">--APLICACIONES INDUSTRIALES--</option>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    <?php endif; ?>
                                                </select>
                                            </td>
                                        </tr>   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php $__currentLoopData = $dositoraxmesact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dositoraxact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_asigdosimTorax[]" id="id_asigdosimTorax" value="<?php echo e($dositoraxact->id_trabajadordosimetro); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimTorax[]" id="id_trabajador_asigdosimTorax<?php echo e($dositoraxact->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dositoraxact->persona_id); ?>"><?php echo e($dositoraxact->persona->primer_nombre_persona); ?> <?php echo e($dositoraxact->persona->segundo_nombre_persona); ?> <?php echo e($dositoraxact->persona->primer_apellido_persona); ?> <?php echo e($dositoraxact->persona->segundo_apellido_persona); ?></option>
                                                    
                                                </select>
                                            </td>
                                            <td>TÓRAX</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimTorax[]" id="id_dosimetro_asigdosimTorax" >
                                                    <option value="<?php if($dositoraxact->dosimetro_id != NULL): ?><?php echo e($dositoraxact->dosimetro_id); ?> <?php endif; ?>"><?php if($dositoraxact->dosimetro_id == NULL): ?>--<?php else: ?> --<?php echo e($dositoraxact->dosimetro->codigo_dosimeter); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresGeneral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosigenlib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosigenlib->id_dosimetro); ?>"><?php echo e($dosigenlib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>N.A</td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimTorax[]" id="ocupacion_asigdosimTorax" style="text-transform:uppercase">
                                                    <?php if($dositoraxact->ocupacion != NULL): ?>    
                                                        <?php if($dositoraxact->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">--TELETERAPIA--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ"-->BRAQUITERAPIA--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">--MEDICINA NUCLEAR--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">--GAMAGRAFIA INDUSTRIAL--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">--MEDIDORES FIJOS--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">--INVESTIGACIÓN--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">--DENSÍMETRO NUCLEAR--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">--MEDIDORES MÓVILES--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">--DOCENCIA--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">--PERFILAJE Y REGISTRO--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">--TRAZADORES--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">--HEMODINAMIA--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">--RAYOS X ODONTOLÓGICO--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">--RADIODIAGNÓSTICO--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">--FLUOROSCOPÍA--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">--APLICACIONES MÉDICAS--</option>
                                                            <?php elseif($dositoraxact->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">--APLICACIONES INDUSTRIALES--</option>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    <?php endif; ?>
                                                </select>
                                            </td>
                                           
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php $__currentLoopData = $dosicristalinomesact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosicristalinoact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_asigdosimCristalino[]" id="id_asigdosimCristalino" value="<?php echo e($dosicristalinoact->id_trabajadordosimetro); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimCristalino[]" id="id_trabajador_asigdosimCristalino<?php echo e($dosicristalinoact->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosicristalinoact->persona_id); ?>"><?php echo e($dosicristalinoact->persona->primer_nombre_persona); ?> <?php echo e($dosicristalinoact->persona->segundo_nombre_persona); ?> <?php echo e($dosicristalinoact->persona->primer_apellido_persona); ?> <?php echo e($dosicristalinoact->persona->segundo_apellido_persona); ?></option>
                                                    
                                                </select>
                                            </td>
                                            <td>CRISTALINO</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimCristalino[]" id="id_dosimetro_asigdosimCristalino">
                                                    <option value="<?php if($dosicristalinoact->dosimetro_id != NULL): ?><?php echo e($dosicristalinoact->dosimetro_id); ?><?php endif; ?>"><?php if($dosicristalinoact->dosimetro_id == NULL): ?>--<?php else: ?>--<?php echo e($dosicristalinoact->dosimetro->codigo_dosimeter); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select"  name="id_holder_asigdosimCristalino[]" id="id_holder_asigdosimCristalino" >
                                                    <option value="<?php if($dosicristalinoact->holder_id != NULL): ?><?php echo e($dosicristalinoact->holder_id); ?><?php endif; ?>"><?php if($dosicristalinoact->holder_id == NULL): ?>--<?php else: ?>--<?php echo e($dosicristalinoact->holder->codigo_holder); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $holderLibresCristalino; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibcris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($holibcris->id_holder); ?>"><?php echo e($holibcris->codigo_holder); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimCristalino[]" id="ocupacion_asigdosimCristalino">
                                                    <?php if($dosicristalinoact->ocupacion != NULL): ?>
                                                        <?php if($dosicristalinoact->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">--TELETERAPIA--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">--BRAQUITERAPIA--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">--MEDICINA NUCLEAR--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">--GAMAGRAFIA INDUSTRIAL--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">--MEDIDORES FIJOS--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">--INVESTIGACIÓN--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">--DENSÍMETRO NUCLEAR--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">--MEDIDORES MÓVILES--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">--DOCENCIA--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">--PERFILAJE Y REGISTRO--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">--TRAZADORES--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">--HEMODINAMIA--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">--RAYOS X ODONTOLÓGICO--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">--RADIODIAGNÓSTICO--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">--FLUOROSCOPÍA--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">--APLICACIONES MÉDICAS--</option>
                                                            <?php elseif($dosicristalinoact->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">--APLICACIONES INDUSTRIALES--</option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>    
                                                    <option value="">----</option>
                                                    <option value="T"> TELETERAPIA</option>
                                                    <option value="BQ">BRAQUITERAPIA</option>
                                                    <option value="MN">MEDICINA NUCLEAR</option>
                                                    <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                    <option value="MF">MEDIDORES FIJOS</option>
                                                    <option value="IV">INVESTIGACIÓN</option>
                                                    <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                    <option value="MM">MEDIDORES MÓVILES</option>
                                                    <option value="E"> DOCENCIA</option>
                                                    <option value="PR">PERFILAJE Y REGISTRO</option>
                                                    <option value="TR">TRAZADORES</option>
                                                    <option value="HD">HEMODINAMIA</option>
                                                    <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                    <option value="RX">RADIODIAGNÓSTICO</option>
                                                    <option value="FL">FLUOROSCOPIA</option>
                                                    <option value="AM">APLICACIONES MÉDICAS</option>
                                                    <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php $__currentLoopData = $dosimuñecamesact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosimuñecact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_asigdosimMuneca[]" id="id_asigdosimMuneca" value="<?php echo e($dosimuñecact->id_trabajadordosimetro); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimMuneca[]" id="id_trabajador_asigdosimMuneca<?php echo e($dosimuñecact->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosimuñecact->persona_id); ?>"> <?php echo e($dosimuñecact->persona->primer_nombre_persona); ?> <?php echo e($dosimuñecact->persona->segundo_nombre_persona); ?> <?php echo e($dosimuñecact->persona->primer_apellido_persona); ?> <?php echo e($dosimuñecact->persona->segundo_apellido_persona); ?></option>
                                                    
                                                </select>
                                            </td>
                                            <td>MUÑECA</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimMuneca[]" id="id_dosimetro_asigdosimMuneca">
                                                    <option value="<?php if($dosimuñecact->dosimetro_id != NULL): ?><?php echo e($dosimuñecact->dosimetro_id); ?><?php endif; ?>"><?php if($dosimuñecact->dosimetro_id == NULL): ?>--<?php else: ?>--<?php echo e($dosimuñecact->dosimetro->codigo_dosimeter); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select"  name="id_holder_asigdosimMuneca[]" id="id_holder_asigdosimMuneca">
                                                    <option value="<?php if($dosimuñecact->holder_id != NULL): ?><?php echo e($dosimuñecact->holder_id); ?><?php endif; ?>"><?php if($dosimuñecact->holder_id == NULL): ?>--<?php else: ?>--<?php echo e($dosimuñecact->holder->codigo_holder); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $holderLibresExtrem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibexm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($holibexm->id_holder); ?>"><?php echo e($holibexm->codigo_holder); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimMuneca[]" id="ocupacion_asigdosimMuneca"  style="text-transform:uppercase">
                                                    <?php if($dosimuñecact->ocupacion != NULL): ?>
                                                        <?php if($dosimuñecact->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">--TELETERAPIA--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">--BRAQUITERAPIA--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">--MEDICINA NUCLEAR--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">--GAMAGRAFIA INDUSTRIAL--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">--MEDIDORES FIJOS--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">--INVESTIGACIÓN--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">--DENSÍMETRO NUCLEAR--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">--MEDIDORES MÓVILES--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">--DOCENCIA--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">--PERFILAJE Y REGISTRO--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">--TRAZADORES--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">--HEMODINAMIA--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">--RAYOS X ODONTOLÓGICO--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">--RADIODIAGNÓSTICO--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">--FLUOROSCOPÍA--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">--APLICACIONES MÉDICAS--</option>
                                                            <?php elseif($dosimuñecact->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">--APLICACIONES INDUSTRIALES--</option>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    <?php endif; ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php $__currentLoopData = $dosidedomesact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosidedoact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="number" name="id_asigdosimDedo[]" id="id_asigdosimDedo" value="<?php echo e($dosidedoact->id_trabajadordosimetro); ?>" hidden>
                                                <select class="form-select"  name="id_trabajador_asigdosimDedo[]" id="id_trabajador_asigdosimDedo<?php echo e($dosidedoact->persona_id); ?>" disabled>
                                                    <option value="<?php echo e($dosidedoact->persona_id); ?>"><?php echo e($dosidedoact->persona->primer_nombre_persona); ?> <?php echo e($dosidedoact->persona->segundo_nombre_persona); ?> <?php echo e($dosidedoact->persona->primer_apellido_persona); ?> <?php echo e($dosidedoact->persona->segundo_apellido_persona); ?></option>
                                                    
                                                </select>
                                            </td>
                                            <td>ANILLO</td>
                                            <td>
                                                <select class="form-select"  name="id_dosimetro_asigdosimDedo[]" id="id_dosimetro_asigdosimDedo"  >
                                                    <option value="<?php if($dosidedoact->dosimetro_id != NULL): ?><?php echo e($dosidedoact->dosimetro_id); ?><?php endif; ?>"><?php if($dosidedoact->dosimetro_id == NULL): ?>-- <?php else: ?>--<?php echo e($dosidedoact->dosimetro->codigo_dosimeter); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $dosimLibresEzclip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosiezcliplib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dosiezcliplib->id_dosimetro); ?>"><?php echo e($dosiezcliplib->codigo_dosimeter); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select"  name="id_holder_asigdosimDedo[]" id="id_holder_asigdosimDedo">
                                                    <option value="<?php if($dosidedoact->holder_id != NULL): ?><?php echo e($dosidedoact->holder_id); ?><?php endif; ?>"><?php if($dosidedoact->holder_id == NULL ): ?>--<?php else: ?>--<?php echo e($dosidedoact->holder->codigo_holder); ?>--<?php endif; ?></option>
                                                    <?php $__currentLoopData = $holderLibresAnillo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holibanillo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($holibanillo->id_holder); ?>"><?php echo e($holibanillo->codigo_holder); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-select" name="ocupacion_asigdosimDedo[]" id="ocupacion_asigdosipDedo">
                                                    <?php if($dosidedoact->ocupacion != NULL): ?>
                                                        <?php if($dosidedoact->ocupacion=='T'): ?>
                                                            <option selected hidden value="T">--TELETERAPIA--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='BQ'): ?>
                                                            <option selected hidden value="BQ">--BRAQUITERAPIA--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='MN'): ?>
                                                            <option selected hidden value="MN">--MEDICINA NUCLEAR--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='GM'): ?>
                                                            <option selected hidden value="GM">--GAMAGRAFIA INDUSTRIAL--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='MF'): ?>
                                                            <option selected hidden value="MF">--MEDIDORES FIJOS--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='IV'): ?>
                                                            <option selected hidden value="IV">--INVESTIGACIÓN--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='DN'): ?>
                                                            <option selected hidden value="DN">--DENSÍMETRO NUCLEAR--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='MM'): ?>
                                                            <option selected hidden value="MM">--MEDIDORES MÓVILES--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='E'): ?>
                                                            <option selected hidden value="E">--DOCENCIA--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='PR'): ?>
                                                            <option selected hidden value="PR">--PERFILAJE Y REGISTRO--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='TR'): ?>
                                                            <option selected hidden value="TR">--TRAZADORES--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='HD'): ?>
                                                            <option selected hidden value="HD">--HEMODINAMIA--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='OD'): ?>
                                                            <option selected hidden value="OD">--RAYOS X ODONTOLÓGICO--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='RX'): ?>
                                                            <option selected hidden value="RX">--RADIODIAGNÓSTICO--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='FL'): ?>
                                                            <option selected hidden value="FL">--FLUOROSCOPÍA--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='AM'): ?>
                                                            <option selected hidden value="AM">--APLICACIONES MÉDICAS--</option>
                                                            <?php elseif($dosidedoact->ocupacion=='AI'): ?>
                                                            <option selected hidden value="AI">--APLICACIONES INDUSTRIALES--</option>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <option value="">----</option>
                                                        <option value="T"> TELETERAPIA</option>
                                                        <option value="BQ">BRAQUITERAPIA</option>
                                                        <option value="MN">MEDICINA NUCLEAR</option>
                                                        <option value="GI">GAMMAGRAFÍA INDUSTRIAL</option>
                                                        <option value="MF">MEDIDORES FIJOS</option>
                                                        <option value="IV">INVESTIGACIÓN</option>
                                                        <option value="DN">DENSÍMETRO NUCLEAR</option>
                                                        <option value="MM">MEDIDORES MÓVILES</option>
                                                        <option value="E"> DOCENCIA</option>
                                                        <option value="PR">PERFILAJE Y REGISTRO</option>
                                                        <option value="TR">TRAZADORES</option>
                                                        <option value="HD">HEMODINAMIA</option>
                                                        <option value="OD">RAYOS X ODONTOLÓGICO</option>
                                                        <option value="RX">RADIODIAGNÓSTICO</option>
                                                        <option value="FL">FLUOROSCOPIA</option>
                                                        <option value="AM">APLICACIONES MÉDICAS</option>
                                                        <option value="AI">APLICACIONES INDUSTRIALES</option>
                                                    <?php endif; ?>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <div class="d-grid gap-2 col-6 mx-auto">
                            <button id="assignBtn" class="btn colorQA"  type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-save" viewBox="0 0 16 16">
                                    <path d="M2 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H9.5a1 1 0 0 0-1 1v7.293l2.646-2.647a.5.5 0 0 1 .708.708l-3.5 3.5a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L7.5 9.293V2a2 2 0 0 1 2-2H14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h2.5a.5.5 0 0 1 0 1H2z"/>
                                </svg> <br> GUARDAR ASIGNACIÓN
                            </button>
                        </div>
                    </div>
                    <div class="col">
                        <div class="d-grip gap-2 col-6 mx-auto">
                            
                            <a href="<?php echo e(route('detallesedecont.create', $contdosisededepto->id_contdosisededepto)); ?>" class="btn btn-danger " type="button" id="cancelar" name="cancelar" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                                </svg> 
                                <br> CANCELAR ASIGNACIÓN
                            </a>
                        </div>
                    </div>
                    <div class="col"></div>

                </div>
            </form>
                    
            
        <br>
    </div>
    <div class="col-md"></div>
</div>
<script
src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous">
</script>

<script type="text/javascript">
    $(document).ready(function(){
        // Creamos array con los meses del año
        const meses = ['ENERO', 'FEBRERO', 'MARZO', 'ABRIL', 'MAYO', 'JUNIO', 'JULIO', 'AGOSTO', 'SEPTIEMBRE', 'OCTUBRE', 'NOVIEMBRE', 'DICIEMBRE'];
        let fecha = new Date("<?php echo e($contdosisededepto->contratodosimetriasede->dosimetriacontrato->fecha_inicio); ?>, 00:00:00");
        
        console.log(fecha);
        for($i=0; $i<=13; $i++){
            var r = new Date(new Date(fecha).setMonth(fecha.getMonth()+$i));
            var fechaesp = meses[r.getMonth()] + ' DE ' + r.getUTCFullYear();
            console.log(r + fechaesp + "ESTA ES LA I"+($i+1)); 
            if("<?php echo e($mesnumber); ?>" == ($i+1)){
                
                document.getElementById('mes<?php echo e($mesnumber); ?>').innerHTML = fechaesp;
            } 
        }
            
    })

</script>
<script type="text/javascript">
   
    function fechaultimodia(){
        var fecha = document.getElementById("primerDia_asigdosim").value;
        var fecha_inicio = new Date(fecha);
        fecha_inicio.setMinutes(fecha_inicio.getMinutes() + fecha_inicio.getTimezoneOffset());
        alert(fecha_inicio);
        console.log("FECHA INICIO"+fecha_inicio);
        if('<?php echo e($contdosisededepto->contratodosimetriasede->dosimetriacontrato->periodo_recambio); ?>' == 'MENS'){
            var fecha_final_año = fecha_inicio.getFullYear();
            console.log(fecha_final_año);
            var mm = fecha_inicio.getMonth() + 2;
            var fecha_final_mes = (mm < 10 ? '0' : '')+mm;
            if(fecha_final_mes == 13){
                fecha_final_mes = '01' ;
            }
            console.log("MES "+fecha_final_mes);
            var dd = fecha_inicio.getDate();
            var fecha_final_dia = (dd < 10 ? '0' : '')+dd;
            console.log("DIA" + fecha_final_dia);
            var fecha_final = new Date(fecha_final_año+'-'+fecha_final_mes+'-'+fecha_final_dia);
            console.log("ESTA ES LA FECHA FINAL" + fecha_final);

            if(fecha_final_mes == 01){
                var fechaFinaly = fecha_final.getFullYear() + 1;
                console.log("AÑO"+fechaFinaly);
            }else{
                var fechaFinaly = fecha_final.getFullYear();
            }
            console.log(fechaFinaly);
            var fechaFinalm = fecha_final.getMonth()+1;
            var fechaFinalmm = (fechaFinalm < 10 ? '0' : '')+fechaFinalm;
            console.log(fechaFinalmm);
            var fechaFinald = fecha_final.getDate();
            var fechaFinaldd = (fechaFinald < 10 ? '0' : '')+fechaFinald;
            console.log(fechaFinaldd);
            var fechaFinalymd = fechaFinaly+'-'+fechaFinalmm+'-'+fechaFinaldd;
            console.log(fechaFinalymd);
            document.getElementById("ultimoDia_asigdosim").value = fechaFinalymd;
        }
    };
    $(document).ready(function(){
        $('#form-nueva-asignacion_mn').submit(function(e){
            e.preventDefault();
            Swal.fire({
                text: "DESEA GUARDAR ESTA ASIGNACIÓN??",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'SI, SEGURO!'
                }).then((result) => {
                if (result.isConfirmed) {
                
                    this.submit();
                }
            })
    })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/dosimetria/asignar_dosimetro_contrato_mn_conovedad.blade.php ENDPATH**/ ?>