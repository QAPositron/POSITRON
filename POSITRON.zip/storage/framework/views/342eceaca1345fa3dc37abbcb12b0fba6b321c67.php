

<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col"></div>
    <div class="col-8">
        <div class="card text-dark bg-light ">
            <h2 class="text-center mt-3">CREAR PERSONA</h2>
            <br>
            <form class="m-4" id="form_create_contacto" name="form_create_contacto" action="<?php echo e(route('personas.save')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-2">
                    <div class="col-md-5">
                        <label for="">PERFIL LABORAL:</label>
                        <div class="form-floating">
                            <select class="form-select <?php $__errorArgs = ['perfil_personas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="perfil_personas[]" id="perfil_personas" autofocus aria-label="Floating label select example"  multiple="true" >
                                <?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value ="<?php echo e($perf->id_perfil); ?>" <?php echo e(in_array($perf->id_perfil, (array) old('perfil_personas', [])) ? "selected" : ""); ?>><?php echo e($perf->nombre_perfil); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                
                            </select>
                            <?php $__errorArgs = ['perfil_personas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md d-flex align-items-center ">
                        <button type="button" class="btn colorQA" data-bs-toggle="modal" data-bs-target="#nueva_perfilModal" >
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
                            </svg>
                        </button>
                    </div>
                    <div class="col-md-6">
                        <label for="">ROL:</label>
                        <div class="form-floating">
                            <select class="form-select <?php $__errorArgs = ['rol_personas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rol_personas[]" id="rol_personas" autofocus aria-label="Floating label select example"  multiple="true" >
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value ="<?php echo e($rol->id_rol); ?>" <?php echo e(in_array($rol->id_rol, (array) old('rol_personas', [])) ? "selected" : ""); ?>><?php echo e($rol->nombre_rol); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                            </select>
                            <?php $__errorArgs = ['rol_personas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    
                    
                </div>
            
                <br>
                
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating text-wrap">
                            <input type="text" class="form-control <?php $__errorArgs = ['primer_nombre_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="primer_nombre_persona" id="primer_nombre_persona" value="<?php echo e(old('primer_nombre_persona')); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">* PRIMER NOMBRE:</label>
                            <?php $__errorArgs = ['primer_nombre_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating text-wrap">
                            <input type="text" class="form-control <?php $__errorArgs = ['segundo_nombre_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="segundo_nombre_persona" id="segundo_nombre_persona" value="<?php echo e(old('segundo_nombre_persona')); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">SEGUNDO NOMBRE:</label>
                            <?php $__errorArgs = ['segundo_nombre_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating text-wrap">
                            <input type="text" class="form-control <?php $__errorArgs = ['primer_apellido_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="primer_apellido_persona" id="primer_apellido_persona" value="<?php echo e(old('primer_apellido_persona')); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">* PRIMER APELLIDO:</label>
                            <?php $__errorArgs = ['primer_apellido_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating text-wrap">
                            <input type="text" class="form-control <?php $__errorArgs = ['segundo_apellido_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="segundo_apellido_persona" id="segundo_apellido_persona" value="<?php echo e(old('segundo_apellido_persona')); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">* SEGUNDO APELLIDO:</label>
                            <?php $__errorArgs = ['segundo_apellido_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating">
                            <select class="form-select <?php $__errorArgs = ['tipoIden_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipoIden_persona" id="tipoIden_persona" value="<?php echo e(old('tipoIden_persona')); ?>" autofocus style="text-transform:uppercase">
                                <option value="">--SELECCIONE--</option>
                                <option value="CÉDULA DE CIUDADANIA" <?php if(old('tipoIden_persona') == "CÉDULA DE CIUDADANIA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>CÉDULA DE CIUDADANIA</option>
                                <option value="TARJETA DE IDENTIDAD" <?php if(old('tipoIden_persona') == "TARJETA DE IDENTIDAD"): ?> <?php echo e('selected'); ?> <?php endif; ?>>TARJETA DE IDENTIDAD</option>
                                <option value="REGISTRO CIVIL" <?php if(old('tipoIden_persona') == "REGISTRO CIVIL"): ?> <?php echo e('selected'); ?> <?php endif; ?>>REGISTRO CIVIL</option>
                                <option value="TARJETA DE EXTRANJERÍA" <?php if(old('tipoIden_persona') == "TARJETA DE EXTRANJERÍA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>TARJETA DE EXTRANJERÍA</option>
                                <option value="DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO" <?php if(old('tipoIden_persona') == "DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO"): ?> <?php echo e('selected'); ?> <?php endif; ?>>DOCUMENTO DE IDENTIFICACIÓN EXTRANJERO</option>
                                <option value="CÉDULA DE EXTRANJERÍA" <?php if(old('tipoIden_persona') == "CÉDULA DE EXTRANJERÍA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>CÉDULA DE EXTRANJERÍA</option>
                                <option value="PASAPORTE"  <?php if(old('tipoIden_persona') == "PASAPORTE"): ?> <?php echo e('selected'); ?> <?php endif; ?>>PASAPORTE</option>
                            </select>
                            <label for="floatingInputGrid">* TIPO DE IDENTIFICACIÓN:</label>
                            <?php $__errorArgs = ['tipoIden_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating text-wrap">
                            <input type="text" class="form-control <?php $__errorArgs = ['cedula_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="cedula_persona" id="cedula_persona" value="<?php echo e(old('cedula_persona')); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">* N° DE IDENTIFICACIÓN:</label>
                            <?php $__errorArgs = ['cedula_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating ">
                            <select class="form-select <?php $__errorArgs = ['genero_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="genero_persona" id="genero_persona" style="text-transform:uppercase;">
                                <option value="<?php echo e(old('genero_persona')); ?>">--SELECCIONE--</option>
                                <option value="femenino" <?php if(old('genero_persona') == "femenino"): ?> <?php echo e('selected'); ?> <?php endif; ?>>FEMENINO</option>
                                <option value="masculino" <?php if(old('genero_persona') == "masculino"): ?> <?php echo e('selected'); ?> <?php endif; ?>>MASCULINO</option>
                                <option value="otro" <?php if(old('genero_persona') == "otro"): ?> <?php echo e('selected'); ?> <?php endif; ?>>OTRO</option>
                            </select>
                            <label for="floatingInputGrid">* GÉNERO:</label>
                            <?php $__errorArgs = ['genero_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-floating text-wrap">
                            <input type="email" class="form-control <?php $__errorArgs = ['correo_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="correo_persona" id="correo_persona" value="<?php echo e(old('correo_persona')); ?>" autofocus style="text-transform:uppercase;">
                            <label for="">* CORREO:</label>
                            <?php $__errorArgs = ['correo_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating text-wrap">
                            <input type="number" class="form-control <?php $__errorArgs = ['telefono_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="telefono_persona" id="telefono_persona" value="<?php echo e(old('telefono_persona')); ?>" autofocus style="text-transform:uppercase;">
                            <label for="floatingInputGrid">* TELÉFONO:</label>
                            <?php $__errorArgs = ['telefono_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md"></div>
                </div>
                <BR>
                <label for="">SELECCIONE SI DESEA RELACIONAR ESTE CONTACTO A UNA EMPRESA Y SUS SEDES</label>
                <br>
                <br>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="form-floating">
                            <select  class="form-select <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_empresas" id="id_empresas">
                                <option value="">--SELECCIONE--</option>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value ="<?php echo e($emp->id_empresa); ?>" <?php if(old('id_empresas') == $emp->id_empresa): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($emp->nombre_empresa); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                            <label for="floatingSelectGrid">EMPRESA:</label>
                            <?php $__errorArgs = ['id_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-1 d-flex align-items-center">
                        <button type="button" class="btn colorQA"  id="agregar" name="agregar">
                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
                            </svg>
                        </button>
                    </div>
                    <div class="col-md">
                        <label for="floatingSelectGrid">SEDE:</label>
                        <div class="spinner_sede text-center" id="spinner_sede">

                        </div>
                        <div class="form-floating" id="sede_empresa" name="sede_empresa">
                            <select class="form-select" id="id_sedes" name="id_sedes[]" autofocus aria-label="Floating label select example"  multiple="true">
                                
                            </select>
                            <?php $__errorArgs = ['sede_empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback">*<?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br>
                <div id="otraEmpresa">

                </div>
                <BR>
                <label for="">A CONTINUACIÓN, SELECCIONE SI ESTE CONTACTO ES EL LÍDER O ENCARGADO DE LOS SERVICIOS:</label>
                
                <div class="row g-2">
                    <div class="col-md"></div>
                    <div class="col-md text-center">
                        <br>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="TRUE" id="lider_contcal" name="lider_contcal" disabled <?php if(old('lider_contcal') == 'TRUE'): ?> checked="checked" <?php endif; ?>>
                            <label class="form-check-label" for="defaultCheck1">
                                CONTROLES DE CALIDAD
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input " type="checkbox" value="TRUE" id="lider_ava" name="lider_ava" disabled <?php if(old('lider_ava') == 'TRUE'): ?> checked="checked" <?php endif; ?>>
                            <label class="form-check-label" for="defaultCheck1">
                                AULA VIRTUAL
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="TRUE" id="lider_dosimetria" name="lider_dosimetria" disabled <?php if(old('lider_dosimetria') == 'TRUE'): ?> checked="checked" <?php endif; ?>>
                            <label class="form-check-label" for="defaultCheck1">
                                DOSIMETRÍA
                            </label>
                        </div>
                    </div>
                    <div class="col-md"></div>
                </div>
                <br>
                <!---------BOTON------------->
                <div class="row">
                    <div class="col"></div>
                    <div class="col d-grid gap-2">
                        <input class="btn colorQA" type="submit" id="boton-guardar" name="boton-guardar" value="GUARDAR">
                    </div>
                    <div class="col d-grid gap-2">
                        <a href="<?php echo e(route('personas.search')); ?>" class="btn btn-danger " type="button" id="cancelar" name="cancelar" role="button">CANCELAR</a>
                    </div>
                    <div class="col"></div>
                </div>
            </form>
        </div>
        <br>
    </div>
    <div class="col"></div>
</div>
<div class="modal fade" id="nueva_perfilModal" tabindex="-1" aria-labelledby="nueva_perfilModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title w-100 text-center" id="nueva_perfilModalLabel">NUEVO PERFIL LABORAL</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form-personas-perfiles')->html();
} elseif ($_instance->childHasBeenRendered('a7fme5V')) {
    $componentId = $_instance->getRenderedChildComponentId('a7fme5V');
    $componentTag = $_instance->getRenderedChildComponentTagName('a7fme5V');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('a7fme5V');
} else {
    $response = \Livewire\Livewire::mount('form-personas-perfiles');
    $html = $response->html();
    $_instance->logRenderedChild('a7fme5V', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
        </div> 
    </div>
</div>


<script
src="https://code.jquery.com/jquery-3.6.0.js"
integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
crossorigin="anonymous">
</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if(session('guardar')== 'ok'): ?>
    <script>
        Swal.fire(
        'GUARDADO!',
        'SE HA GUARDADO CON ÉXITO.',
        'success'
        )
    </script>
<?php endif; ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('#form_crear_perfil').submit(function(e){
            e.preventDefault();
            Swal.fire({
                text: "DESEA GUARDAR ESTE PERFIL LABORAL??",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'SI, SEGURO!'
                }).then((result) => {
                if (result.isConfirmed) {
                   
                    this.submit();
                }
            })
        })
    });
    $(document).ready(function(){
        $('#form_crear_rol').submit(function(e){
            e.preventDefault();
            Swal.fire({
                text: "DESEA GUARDAR ESTE ROL??",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'SI, SEGURO!'
                }).then((result) => {
                if (result.isConfirmed) {
                   
                    this.submit();
                }
            })
        })
    });
    $(document).ready(function(){
        $('#lider_dosimetria').on('change', function(){
            var values="2,";
            var lider = document.getElementById("lider_dosimetria").value;
            if(lider == 'TRUE'){
                
                $.each(values.split(","), function(i,e){
                    $("#rol_personas option[value='" + e + "']").prop("selected", true);
                });
            }
        })        
        $('#id_empresas').on('change', function(){

            $('#sede_empresa').fadeOut();
            $('#spinner_sede').html('<div class="spinner-border text-secondary" id="spinner" role="status"></div>');
            var empresa_id = $(this).val();
            console.log("estado de la empresa" + empresa_id)
            var padre = document.getElementById("spinner_sede");
            var hijo = document.getElementById("spinner");
            if($.trim(empresa_id) != ''){
                $.get('selectsedes',{empresa_id : empresa_id}, function(sedes){
                    console.log(sedes);
                    var remove = padre.removeChild(hijo);
                    $('#sede_empresa').fadeIn();
                    $('#id_sedes').empty();
                    $('#id_sedes').append("<option value=''>--SELECCIONE UNA SEDE--</option>");
                    $.each(sedes, function(index, value){
                        $('#id_sedes').append("<option value='"+ index + "'>" + value + "</option>");
                    })
                });
            }else{
                var remove = padre.removeChild(hijo);
                $('#sede_empresa').fadeIn();
                
            }
            
            $("#lider_contcal").removeAttr('disabled');
            $("#lider_ava").removeAttr('disabled');
            $("#lider_dosimetria").removeAttr('disabled');
        });
    });
   
    $(document).ready(function(){
        var i = 1;
        $("#agregar").click(function(){

            $("#otraEmpresa").append(
                '<div class="row g-2" id="row'+i+'">'
                    +'<div class="col-md">'
                        +'<div class="form-floating">'
                            +'<select class="form-select" name="id_empresas_add[]" id="id_empresas'+i+'">'
                                +'<option value="">--SELECCIONE--</option>'
                                +'<?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'
                                    +'<option value ="<?php echo e($emp->id_empresa); ?>"><?php echo e($emp->nombre_empresa); ?></option>'
                                +'<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'
                            +'</select>'
                            +'<label for="floatingSelectGrid">EMPRESA:</label>'
                            
                        +'</div>'
                    +'</div>'
                    +'<div class="col-md-1 d-flex align-items-center">'    
                        +'<button id="remove'+i+'" class="btn btn-danger"  type="button">'
                            +'<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">'
                                +'<path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>'
                            +'</svg>'
                        +'</button>'
                    +'</div>'
                    +'<div class="col-md">'
                        +'<label for="floatingSelectGrid">SEDE:</label>'
                        +'<div class="spinner_sede text-center" id="spinner_sede'+i+'"></div>'
                        +'<div class="form-floating" id="sede_empresa'+i+'" name="sede_empresa">'
                            +'<select class="form-select" id="id_sedes'+i+'" name="id_sedes_add[]" autofocus aria-label="Floating label select example"  multiple="true">'
                                
                            +'</select>'
                        +'</div>'
                    +'</div>'
                    
                +'</div>'
                +'<br>'
            );
            
            $('#id_empresas'+i).on('change', function(){
                
                $('#sede_empresa'+(i-1)).fadeOut();
                $('#spinner_sede'+(i-1)).html('<div class="spinner-border text-secondary" id="spinner'+(i-1)+'" role="status"></div>');
                var empresa_id = $(this).val();
                var padre = document.getElementById("spinner_sede"+(i-1));
                var hijo = document.getElementById("spinner"+(i-1));
                if($.trim(empresa_id) != ''){
                    $.get('selectsedes',{empresa_id : empresa_id}, function(sedes){
                        console.log(sedes);
                        var remove = padre.removeChild(hijo);
                        $('#sede_empresa'+(i-1)).fadeIn();
                        $('#id_sedes'+(i-1)).empty();
                        $('#id_sedes'+(i-1)).append("<option value=''>--SELECCIONE UNA SEDE--</option>");
                        $.each(sedes, function(index, value){
                            $('#id_sedes'+(i-1)).append("<option value='"+ index + "'>" + value + "</option>");
                        })
                    });
                }
                
            });
            $('#remove'+i).click(function(){
                $('#row'+(i-1)).remove();
                
            })
            $('#id_sedes'+i).select2({
                placeholder:"SELECCIONE LAS SEDES",
                tags: true,
                tokenSeparators: ['/',',',',',','," "]
            });
            i++;
        }); 
    });

   
    
</script>

<script type="text/javascript">
    $(document).ready(() => {

        $('#rol_personas').select2({
            placeholder:"SELECCIONE LOS ROLES",
            tags: true,
            tokenSeparators: ['/',',',',',','," "]
        });
        
        $('#perfil_personas').select2({
            placeholder:"SELECCIONE LOS PERFILES LABORALES",
            tags: true,
            tokenSeparators: ['/',',',',',','," "]
        });
        $('#id_sedes').select2({
            placeholder:"SELECCIONE LAS SEDES",
            tags: true,
            tokenSeparators: ['/',',',',',','," "]
        });
        
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#form_create_contacto').submit(function(e){
            e.preventDefault();
            Swal.fire({
                text: "DESEA GUARDAR ESTA PERSONA??",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'SI, SEGURO!'
                }).then((result) => {
                if (result.isConfirmed) {
                   
                    this.submit();
                }
            })
        })
    })
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/persona/crear_persona.blade.php ENDPATH**/ ?>