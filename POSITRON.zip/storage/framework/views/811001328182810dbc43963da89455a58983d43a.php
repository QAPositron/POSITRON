<div>
    <form action="<?php echo e(route('perfiles.save')); ?>" method="POST"  id="form_crear_perfil" name="form_crear_perfil" >
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="col-md">
                <label class="text-center">INGRESE EL NOMBRE DEL PERFIL LABORAL QUE DESEA GUARDAR:</label>
                <br>
                <div class="form-floating">
                    <input wire:model="nombre_perfil_laboral" type="text" class="form-control <?php $__errorArgs = ['nombre_perfil_laboral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre_perfil_laboral" id="nombre_perfil_laboral" autofocus style="text-transform:uppercase">
                    <label for="floatingSelectGrid">PERFIL LABORAL:</label>
                    <?php $__errorArgs = ['nombre_perfil_laboral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback">*<?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">CANCELAR</button>
            <button type="submit" class="btn colorQA"  data-bs-dismiss="modal" >GUARDAR</button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/livewire/form-personas-perfiles.blade.php ENDPATH**/ ?>