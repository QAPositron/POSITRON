<div>
    
    <form action="<?php echo e(route('departamento.save')); ?>" method="POST"  id="form_crear_rol" name="form_crear_rol" >
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="col-md">
                <label class="text-center">INGRESE EL NOMBRE DE LA ESPECIALIDAD QUE DESEA GUARDAR:</label>
                <br>
                <div class="form-floating">
                    <input wire:model="nombre_departamento" type="text"class="form-control <?php $__errorArgs = ['nombre_departamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre_departamento" id="nombre_departamento" autofocus style="text-transform:uppercase">
                    <label for="floatingSelectGrid">ESPECIALIDAD:</label>
                    <?php $__errorArgs = ['nombre_departamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback">*<?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">CANCELAR</button>
            <button type="submit" class="btn colorQA"  data-bs-dismiss="modal" >GUARDAR</button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/livewire/form-departamentosedes.blade.php ENDPATH**/ ?>