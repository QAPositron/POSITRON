
<?php $__env->startSection('contenido'); ?>
 <h3 class="text-center"> BIENVENIDO A QAPOSITRON</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/home/home.blade.php ENDPATH**/ ?>