

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-asignaciones')->html();
} elseif ($_instance->childHasBeenRendered('yvuQ5Sr')) {
    $componentId = $_instance->getRenderedChildComponentId('yvuQ5Sr');
    $componentTag = $_instance->getRenderedChildComponentTagName('yvuQ5Sr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yvuQ5Sr');
} else {
    $response = \Livewire\Livewire::mount('search-asignaciones');
    $html = $response->html();
    $_instance->logRenderedChild('yvuQ5Sr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSITRON\resources\views/dosimetria/revision_asignaciones_dosimetria_general1.blade.php ENDPATH**/ ?>